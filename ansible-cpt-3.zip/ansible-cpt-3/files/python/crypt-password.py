import crypt
import sys

password = sys.argv[1]
method = crypt.METHOD_SHA512
print(crypt.crypt(password, method))
