#!/usr/bin/python3

import argparse
import ca_functions
import json

# ----------------
# Argparse setup.
# ----------------

parser = argparse.ArgumentParser()
parser.add_argument(
    "-k",
    "--key",
    dest="key",
    required=True,
    type=str,
    help="Decryption Key.",
    nargs=1,
    metavar="KEY",
)
parser.add_argument(
    "-i",
    "--iv",
    dest="iv",
    required=True,
    type=str,
    help="IV Value.",
    nargs=1,
    metavar="IV",
)
parser.add_argument(
    "-s",
    "--secret",
    dest="secret",
    required=True,
    type=str,
    help="Encrypted secret.",
    nargs=1,
    metavar="SECRET",
)
args = parser.parse_args()

key = str(args.key[0])
iv = str(args.iv[0])
secret = str(args.secret[0])

result = {"result": ca_functions.decrypt(secret, key, iv)}

print(json.dumps(result))
