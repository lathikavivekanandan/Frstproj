import os
import sys
from ansible_vault import Vault

vault_password = os.getenv("ANSIBLE_VAULT_PASSWORD")
vault_file = sys.argv[1]
query_key = sys.argv[2]

vault = Vault(vault_password)
vault_content = vault.load(open(vault_file).read())
print(vault_content[query_key])
