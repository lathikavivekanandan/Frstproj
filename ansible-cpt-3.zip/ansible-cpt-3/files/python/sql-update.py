# --------------------------
# Define modules to import.
# --------------------------

import pymssql
import sys
import json
from ca_functions import get_tss_secret

# -------------------------------
# Define command line variables.
# -------------------------------

sql_secret = int(sys.argv[1])
update_proc = str(sys.argv[2])
update_dict = json.loads(sys.argv[3])


# -------------
# Script body.
# -------------

db = get_tss_secret(sql_secret)

if update_proc == "dbo.AnsibleFact_InsertOrUpdate":
    update_dict["AnsibleFacts"][0]["CoreMachineID"] = int(update_dict["AnsibleFacts"][0]["CoreMachineID"])

update_dict_json = json.dumps(update_dict)
print(update_dict_json)
with pymssql.connect(
    server=db["server"],
    port=str(db["port"]),
    database=db["database"],
    user=db["username"],
    password=db["password"],
    autocommit=True,
) as conn:
    with conn.cursor() as cur:
        try:
            cur.callproc(update_proc, (update_dict_json,))
        except pymssql.Error as e:
            sys.exit("Error updating database: " + str(e.message))
        except:
            sys.exit("Unknown error updating database.")
