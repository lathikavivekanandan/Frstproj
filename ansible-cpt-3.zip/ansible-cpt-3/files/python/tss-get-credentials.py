#!/usr/bin/python3.11

# Import modules

import os
import sys
import json
from ca_functions import decrypt

# Check required env vars are set

for env_var in ["TSS_DECRYPTION_IV", "TSS_DECRYPTION_KEY", "SECRET_STRING"]:
    if os.getenv(env_var, default=None) is None:
        print("Environment variable " + env_var + " not defined.")
        sys.exit(1)

result = json.loads(
    decrypt(
        os.getenv("SECRET_STRING"),
        os.getenv("TSS_DECRYPTION_KEY"),
        os.getenv("TSS_DECRYPTION_IV"),
    )
)

result_json = json.dumps(result)
print(result_json)
