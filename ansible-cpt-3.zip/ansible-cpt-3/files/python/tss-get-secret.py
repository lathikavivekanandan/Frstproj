# Define imports

import sys
import json
from ca_functions import get_tss_secret as get_secret

# Begin script

if len(sys.argv) < 2:
    sys.exit("No secret id provided.")
else:
    secret_id = int(sys.argv[1])

secret = get_secret(secret_id)
secret_json = json.dumps(secret)
print(secret_json)
