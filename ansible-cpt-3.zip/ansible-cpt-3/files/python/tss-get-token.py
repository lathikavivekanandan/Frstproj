# Define imports

import os
import sys
from ca_functions import get_tss_token as get_token

# Begin script

for env_var in ["TSS_USERNAME", "TSS_PASSWORD"]:
    if os.getenv(env_var, default=None) is None or os.getenv(env_var, default=None) == "":
        sys.exit("Environment variable " + env_var + " not defined.")
token = get_token(os.getenv("TSS_USERNAME"), os.getenv("TSS_PASSWORD"))
print(token)
