$filelocation ="C:\Software\SqlServer\22.2.0\SqlServer.psm1"
$filelocation1 ="‪C:\Software\SqlServer\22.2.0\SqlNotebook.psm1"
Import-Module $filelocation



[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12



[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12

add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
 Write-host "successfully imported Modules and assembly required to perform the operation" -ForegroundColor White
# Define the API endpoint
$apiUrl = "https://IdentityService-prod.vdc.nz/oauth2/token"
$apiurl_cart="https://swat-wpd-id-cart-com-prod.vdc.nz/connect/token"
$username="lathika.com.auto"


$securePassword = Get-Content "C:\users\lvivekanandan\desktop\encrypted_password.txt" | ConvertTo-SecureString
$password = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword))
 
$body = @{
    grant_type = "password"
    client_id = "325E6995-2234-42C7-95FF-B9006FEADCF3"
    username = $username
    password = $password
}
$headers = @{
    "Content-Type" = "application/x-www-form-urlencoded"
}


$headers_cart = @{
    "Accept" = "*/*"
    "Accept-Encoding" = "gzip, deflate"
    "Cache-Control" = "no-cache, no-cache"
    "Host" = "swat-wpd-id-cart-com-prod.vdc.nz"
    "Postman-Token" = "02b8a613-5050-4365-bae2-5f7d6e26b7f1,5bceed52-98a7-4e6b-bd75-c85bd1ba11d4"
}
$body_cart = @{
    "client_id" = "58cdeb3a-9492-4329-a2b6-a8046cf0451b"
    "client_secret" = "92837ca777ea4210bab578e568b6dd49ba93e00801804a60b675d9ce0130d73b"
    "grant_type" = "client_credentials"
    "user_name" = "lvivekanandan"
    "email_address" = "lathika.vivekanandan@concepts.co.nz"
    "first_name" = "firstname"
    "last_name" = "lastname"
    "idp" = "http://adfs.revera.co.nz/adfs/services/trust"
    "security_groups" = "| SWAT Team |"
    "mobile_number" = ""
}
$response = Invoke-WebRequest -Uri "https://swat-wpd-id-cart-com-prod.vdc.nz/connect/token" `
    -Method Post `
    -Headers $headers_cart `
    -ContentType "application/x-www-form-urlencoded" `
    -UserAgent "PostmanRuntime/7.16.3" `
    -Body $body_cart


$accessToken = ($response.Content | ConvertFrom-Json).access_token.Trim()
write-host "Generated token for Cart api" -ForegroundColor White

$server = "rvrci2sqlav2.vdc.nz"
$database = "master"

$desiredVMNamess=@(
)

$tenant=@("CCL ORPHAN COM (LIVE)")


$reassignquery= @"
SELECT
    [UUID],
    [Name] 
    FROM 
     [ReveraSI_prod].[dbo].[tblCustomer] 
WHERE 
    [Name] LIKE '%$tenant%' 
"@



$reassignconn= Invoke-SQLCmd -Query $reassignquery -ServerInstance $server -Database $database  -Encrypt Optional
$targetuuid=$reassignconn.UUID.Guid

Write-host "Hitting Reassign api" -ForegroundColor White
$url = 'https://swat-wpd-api-cart-com-prod.vdc.nz/Tenancy/api/User/ReassignCCUserAccount'
$headers_reassign = @{
    "accept" = "text/plain"
    "Authorization" = "Bearer $accessToken"
    "Content-Type" = "application/json-patch+json"
}



# Output the response

# Define the URL and headers


# Define the JSON body
$body_reassign = @{
    ccUserGuid = "7C3CC961-BF59-4B67-BE19-55EF6DB745E4"
    emailAddress = "lathika.vivekanandan@concepts.co.nz"
    ccUserName = $username
    supportTicket = "SCTASK003447801"
    currentCustomerGuid = "8AACB639-4B56-4C70-87E4-FA995B8EE50E"
    firstName = ""
    mobileNumber = ""
    currentCustomerName = "CCL COM SWAT AUTOMATION (TRIAL)"
    cartUserName = "lVivekanandan"
    lastName = ""
    targetCustomerGuid = $targetuuid
    isAogUser = $false
    roles = $null
} | ConvertTo-Json

<#$body_reassign = @{
    ccUserGuid = "13DE813C-7795-4E27-B3A2-3418FA612BA3"
    emailAddress = "abirath.amirtharaj@concepts.co.nz"
    ccUserName = "abirath.aog.ga"
    supportTicket = "SCTASK003447801"
    currentCustomerGuid = "C4DA81C4-A8AA-41B5-A050-29A4029E8433"
    firstName = ""
    mobileNumber = ""
    currentCustomerName = "CCL SWAT AOG (TRIAL)"
    cartUserName = "aamirtharaj"
    lastName = ""
    targetCustomerGuid = $targetuuid
    isAogUser = $false
    roles = $null
} | ConvertTo-Json #>

# Make the POST request
$response_reassign = Invoke-RestMethod -Uri $url -Method Post -Headers $headers_reassign -Body $body_reassign

# Output the response


  if ($response_reassign -eq "True"){
    write-host "Reassigned the user successfully " -ForegroundColor Green
    }
    else{
    Write-Host "some error occured when reassigning " -ForegroundColor Red
    
    }
    
  $response = Invoke-RestMethod -Uri $apiUrl -Method Post -Headers $headers -Body $body
$token = $response.access_token
#$token="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOlsiQ2xvdWRBZG1pbiIsIkFkbWluQ29tbXZhdWx0VjIiLCJBV1NBZG1pbiIsIkF6dXJlQWRtaW4iLCJCaWxsaW5nQWRtaW4iLCJERkFBZG1pbiIsIkZpbGVUcmFuc2ZlckFkbWluIiwiTWFya2V0UGxhY2VBZG1pbiIsIlJlcG9ydEFkbWluIiwiU2VydmljZURlc2tBZG1pbiIsIlNpbHZlci1saW5pbmdEUmZvcnZDbG91ZFBBWUdBZG1pbiIsIlZhdWx0QWRtaW4iLCJWQ2xvdWRBZG1pbiIsInZDbG91ZFBBWUdBZG1pbiIsIlZtd2FyZUFkbWluIiwiSURNX0FETUlOIiwiSURNX1VTRVIiXSwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbmFtZSI6ImFiaXJhdGguYW9nLmdhIiwiY2xpZW50IjoiYXV0aC5ob21lbGFuZC5yZXZlcmEuY28ubnoiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjEzZGU4MTNjLTc3OTUtNGUyNy1iM2EyLTM0MThmYTYxMmJhMyIsImN1c3RvbWVydXVpZCI6IjlkMmRmM2NiLTY3ZWItNDA4ZC1iZTEwLTJlZDdmZjVlMGRjMSIsImlzYW9nIjoiVHJ1ZSIsImNsb3VkcyI6IjlkMmRmM2NiLTY3ZWItNDA4ZC1iZTEwLTJlZDdmZjVlMGRjMSIsImNyeXB0IjoiMCIsIm5iZiI6MTcxOTQ0MzY4MSwiZXhwIjoxNzE5NDcyNDgxLCJpc3MiOiJzd2F0LWFwaS1hb2ctcHJvZC52ZGMubnoiLCJhdWQiOiI5MzI4YjQ1OS1mODEzLTQzMWMtODZmZC1iYTViOGExMjI3YjQifQ.GZgIOH2cCYol-5Q4RHlPNrEVfP_T9cguR787baEoRQ1BUASYknhwog1BHHg9KDw2Yj0RJCFtmR1RDJLwixOq_V0blBb75B2tO7wUI3XcigHTM049puyx-jDa-VJwhSL_CXY3mGvSPTJP1nH4ARM9SiJhTD8C5S45-rpO4jevZUp-H-0XEfbByNR-jDCTHlvl-Sy3SJ2HLkqinaNhm0MBE2Nm7ind_B0fUAGVznCD9rmmfGsMbD6u9RF7Blr9RhfAmgaENRqU5x1HE7X4o5g9N-8OT--Z4974PNi2J1EV9AvvetkOeqbJ_27ujF-ZbCZzEbLQX6yOJ6key3babsrfEQ"
write-host "Generated token for Revera api" -ForegroundColor White

  $apiHeaders = @{
        "Authorization" = "$token"
        "Accept" = "text/plain"
    }
$vmurl="https://reveraapi-prod.vdc.nz/api/VirtualMachine/Datacenter/Machines?cloudGuid=$targetuuid&returnGuidInVMName=true"
 #$vmurl="https://swat-wpd-api-aog-prod.vdc.nz/api/VirtualMachine/Datacenter/Machines?cloudGuid=$targetuuid&returnGuidInVMName=true"

   $vmResponse = Invoke-restmethod -Uri $vmUrl -Method GET -Headers $apiHeaders
   
$filteredVMs = $vmResponse | Where-Object { $desiredVMNamess -contains $_.ServerName }

# Output the filtered VMs
$filteredVMs | ForEach-Object {
    Write-Output "VMName: $($_.VMName)"
    Write-Output "BackupEnabled: $($_.BackupEnabled)"
    Write-Output "---------------------------"
}


$desiredVMNamess=@(
'strarthocadmn',
'strarthoccc',
'STRARTHOCPROBE-PRT',
'STRPRTHOCPROBE-ART'
)
foreach($desiredVMNames in $desiredVMNamess){


$query = @"
SELECT
    [UUID],
    [VMName]
FROM 
    [ReveraSI_prod].[Compute].[Machine] 
WHERE 
    [VMName] in (`'$desiredVMNames'`) AND [active] = 1 
"@

$conn=Invoke-SQLCmd -Query $query -ServerInstance $server -Database $database  -Encrypt Optional  
$uuid= $conn.UUID.Guid


$deleteurl="https://reveraapi-prod.vdc.nz/api/VirtualMachine?machineGuid=$uuid"

$deleteHeaders = @{
        "Authorization" = "$token"
        "Accept" = "application/json"
    }
    $deleteResponse = Invoke-restmethod -Uri $deleteUrl -Method Delete -Headers $deleteHeaders
     write-host $deleteResponse for $desiredVMNames
   


}
