
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$filelocation ="C:\Software\SqlServer\22.2.0\SqlServer.psm1"
$filelocation1 ="‪C:\Software\SqlServer\22.2.0\SqlNotebook.psm1"
Import-Module $filelocation



[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12



[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12

add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
 Write-host "successfully imported Modules and assembly required to perform the operation" -ForegroundColor White


# Function to create the main form
function Show-BackupForm {
    # Create a new form
    $form = New-Object Windows.Forms.Form
    $form.Text = "Backup Manager"
    $form.Size = New-Object Drawing.Size(450, 350)
    $form.StartPosition = "CenterScreen"

    # Create controls
    $enableButton = New-Object Windows.Forms.Button
    $enableButton.Text = "Enable Backup"
    $enableButton.Size = New-Object Drawing.Size(150, 40)
    $enableButton.Location = New-Object Drawing.Point(50, 250)
    
    $disableButton = New-Object Windows.Forms.Button
    $disableButton.Text = "Disable Backup"
    $disableButton.Size = New-Object Drawing.Size(150, 40)
    $disableButton.Location = New-Object Drawing.Point(200, 250)

    $serviceLevelLabel = New-Object Windows.Forms.Label
    $serviceLevelLabel.Text = "Service Level:"
    $serviceLevelLabel.Location = New-Object Drawing.Point(20, 20)

    $serviceLevelComboBox = New-Object Windows.Forms.ComboBox
    $serviceLevelComboBox.Items.AddRange(@("Economy", "Standard", "Premium"))
    $serviceLevelComboBox.Location = New-Object Drawing.Point(150, 20)
    $serviceLevelComboBox.SelectedIndex = 0

    $retentionLabel = New-Object Windows.Forms.Label
    $retentionLabel.Text = "Retention Copy:"
    $retentionLabel.Location = New-Object Drawing.Point(20, 60)

    $retentionComboBox = New-Object Windows.Forms.ComboBox
    $retentionComboBox.Items.AddRange(@("Vault90Day", "Vault1Year", "Vault7Year","Vault10year","None"))
    $retentionComboBox.Location = New-Object Drawing.Point(150, 60)
    $retentionComboBox.SelectedIndex = 0

    $offsiteLabel = New-Object Windows.Forms.Label
    $offsiteLabel.Text = "Offsite Copy:"
    $offsiteLabel.Location = New-Object Drawing.Point(20, 100)

    $offsiteCheckBox = New-Object Windows.Forms.CheckBox
    $offsiteCheckBox.Location = New-Object Drawing.Point(150, 100)

    $csvLabel = New-Object Windows.Forms.Label
    $csvLabel.Text = "CSV File:"
    $csvLabel.Location = New-Object Drawing.Point(20, 140)

    $csvTextBox = New-Object Windows.Forms.TextBox
    $csvTextBox.Size = New-Object Drawing.Size(200, 20)
    $csvTextBox.Location = New-Object Drawing.Point(150, 140)
    
    $browseButton = New-Object Windows.Forms.Button
    $browseButton.Text = "Browse"
    $browseButton.Size = New-Object Drawing.Size(70, 20)
    $browseButton.Location = New-Object Drawing.Point(360, 140)

    # Add controls to the form
    $form.Controls.Add($enableButton)
    $form.Controls.Add($disableButton)
    $form.Controls.Add($serviceLevelLabel)
    $form.Controls.Add($serviceLevelComboBox)
    $form.Controls.Add($retentionLabel)
    $form.Controls.Add($retentionComboBox)
    $form.Controls.Add($offsiteLabel)
    $form.Controls.Add($offsiteCheckBox)
    $form.Controls.Add($csvLabel)
    $form.Controls.Add($csvTextBox)
    $form.Controls.Add($browseButton)


    $username="lathika.com.auto"
    $email="lathika.vivekanandan@concepts.co.nz"
    # Function to get the token
    function Get-Token {
      write-host "Generating token for reveraapi"
        $apiUrl = "https://IdentityService-prod.vdc.nz/oauth2/token"
        $body = @{
            grant_type = "password"
            client_id = "325E6995-2234-42C7-95FF-B9006FEADCF3"
            username = $username
            password = ""
        }
        $headers = @{
            "Content-Type" = "application/x-www-form-urlencoded"
        }
        $response = Invoke-RestMethod -Uri $apiUrl -Method Post -Headers $headers -Body $body
        return $response.access_token
    }

    # Function to get the target UUID
    function Get-TargetUUID {
        param (
            [string]$tenant
        )
$server = "rvrci2sqlav2.vdc.nz"
$database = "master"
$query= @"
SELECT
    [UUID],
    [Name] 
    FROM 
     [ReveraSI_prod].[dbo].[tblCustomer] 
WHERE 
    [Name] LIKE '%$tenant%' 
"@


$reassignconn= Invoke-SQLCmd -Query $query -ServerInstance $server -Database $database  -Encrypt Optional
       
 return $reassignconn.UUID.Guid
 }
    

    # Function to reassign the user
 function Reassign-User {
        param (
            [string]$username,
            [string]$email,
            [string]$targetuuid,
            [string]$token
        )

        $headers_cart = @{
    "Accept" = "*/*"
    "Accept-Encoding" = "gzip, deflate"
    "Cache-Control" = "no-cache, no-cache"
    "Host" = "swat-wpd-id-cart-com-prod.vdc.nz"
    "Postman-Token" = "02b8a613-5050-4365-bae2-5f7d6e26b7f1,5bceed52-98a7-4e6b-bd75-c85bd1ba11d4"
}
$body_cart = @{
    "client_id" = "58cdeb3a-9492-4329-a2b6-a8046cf0451b"
    "client_secret" = "92837ca777ea4210bab578e568b6dd49ba93e00801804a60b675d9ce0130d73b"
    "grant_type" = "client_credentials"
    "user_name" = "lvivekanandan"
    "email_address" = "lathika.vivekanandan@concepts.co.nz"
    "first_name" = "firstname"
    "last_name" = "lastname"
    "idp" = "http://adfs.revera.co.nz/adfs/services/trust"
    "security_groups" = "| SWAT Team |"
    "mobile_number" = ""
}
$response = Invoke-WebRequest -Uri "https://swat-wpd-id-cart-com-prod.vdc.nz/connect/token" -Method Post  -Headers $headers_cart  -ContentType "application/x-www-form-urlencoded"  -UserAgent "PostmanRuntime/7.16.3" -Body $body_cart


$accessToken = ($response.Content | ConvertFrom-Json).access_token.Trim()
write-host "Generated token for Cart api" -ForegroundColor White

        $url = 'https://swat-wpd-api-cart-com-prod.vdc.nz/Tenancy/api/User/ReassignCCUserAccount'
        $headers = @{
            "accept" = "text/plain"
            "Authorization" = "Bearer $accesstoken"
            "Content-Type" = "application/json-patch+json"
        }
        $body = @{
            ccUserGuid = "7C3CC961-BF59-4B67-BE19-55EF6DB745E4"
            emailAddress = $email
            ccUserName = $username
            supportTicket = "SCTASK003447801"
            currentCustomerGuid = "8AACB639-4B56-4C70-87E4-FA995B8EE50E"
            firstName = ""
            mobileNumber = ""
            currentCustomerName = "CCL COM SWAT AUTOMATION (TRIAL)"
            cartUserName = "lVivekanandan"
            lastName = ""
            targetCustomerGuid = $targetuuid
            isAogUser = $false
            roles = $null
        } | ConvertTo-Json

        $response = Invoke-RestMethod -Uri $url -Method Post -Headers $headers -Body $body

        if ($response -eq $true) {
            Write-Host "Reassigned the user successfully" -ForegroundColor Green
        } else {
            Write-Host "Some error occurred when reassigning" -ForegroundColor Red
        }
    }

    # Function to enable backup
    function Enable-Backup {
        param (
            [string]$vmName,
            [string]$serviceLevel,
            [string]$retentionCopy,
            [bool]$offsiteCopy,
            [string]$targetuuid,
            [string]$token,
            [string]$tenant
        )
        write-host "Trying to enable backup"
  $server = "rvrci2sqlav2.vdc.nz"
  $database = "master"
        
  $query = @"
        SELECT
            [UUID],
            [VMName]
        FROM 
            [ReveraSI_prod].[Compute].[Machine] 
        WHERE 
            [VMName] LIKE '%$vmName%' AND [active] = 1
"@
      

        $conn = Invoke-SQLCmd -Query $query -ServerInstance $server -Database $database -Encrypt Optional  
        $uuid = $conn.UUID.Guid

        $headers = @{
            'Content-Type'    = 'application/json'
            'Accept'          = 'application/json'
            'Authorization'   = $token
        }
        
        $body = @{
            "OperationType"     = "OnboardVM"
            "VendorType"        = "VMware"
            "CloudGuid"         = $targetuuid
            "MachineGuid"       = $uuid
            "VmGuid"            = $uuid
            "CloudName"         = $tenant
            "SuppressBilling"   = $false
            "ServiceLevel"      = $serviceLevel
            "OffsiteCopy"       = $offsiteCopy
            "LongTermRetention" = $retentionCopy
        } | ConvertTo-Json

        $enable = Invoke-RestMethod -Uri 'https://reveraapi-prod.vdc.nz/api/Backup/RequestBackup' -Method Post -Headers $headers -Body $body
        if ($enable -eq 'true') {
            Write-Host "Enabled backup for $vmName" -ForegroundColor Green
        } else {
            Write-Host "Failed to enable backup for $vmName" -ForegroundColor Red
        }
    }

    # Function to disable backup
    function Disable-Backup {
        param (
            [string]$vmName,
            [string]$serviceLevel,
            [string]$retentionCopy,
            [bool]$offsiteCopy,
            [string]$targetuuid,
            [string]$token,
            [string]$tenant
        )

        # Implementation to disable backup

        $server = "rvrci2sqlav2.vdc.nz"
  $database = "master"
        
  $query = @"
        SELECT
            [UUID],
            [VMName]
        FROM 
            [ReveraSI_prod].[Compute].[Machine] 
        WHERE 
            [VMName] LIKE '%$vmName%' AND [active] = 1
"@
      

        $conn = Invoke-SQLCmd -Query $query -ServerInstance $server -Database $database -Encrypt Optional  
        $uuid = $conn.UUID.Guid

        $headers = @{
            'Content-Type'    = 'application/json'
            'Accept'          = 'application/json'
            'Authorization'   = "Bearer $token"
        }
        
        $body = @{
            "OperationType"     = "OffboardVirtualMachine"
            "VendorType"        = "VMware"
            "CloudGuid"         = $targetuuid
            "MachineGuid"       = $uuid
            "VmGuid"            = $uuid
            "CloudName"         = $tenant
            "SuppressBilling"   = $false
            "ServiceLevel"      = $serviceLevel
            "OffsiteCopy"       = $offsiteCopy
            "LongTermRetention" = $retentionCopy
        } | ConvertTo-Json

        $enable = Invoke-RestMethod -Uri 'https://reveraapi-prod.vdc.nz/api/Backup/RequestBackup' -Method Post -Headers $headers -Body $body
        if ($enable -eq 'true') {
            Write-Host "Disabled backup for $vmName" -ForegroundColor Green
        } else {
            Write-Host "Failed to disable backup for $vmName" -ForegroundColor Red
        }
    
        
    }

    # Function to browse for a CSV file
    function Browse-CSVFile {
        $openFileDialog = New-Object System.Windows.Forms.OpenFileDialog
        $openFileDialog.Filter = "CSV files (*.csv)|*.csv"
        if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $csvTextBox.Text = $openFileDialog.FileName
        }
    }

   # Event handlers for buttons
    $browseButton.Add_Click({
        Browse-CSVFile
    })

    $enableButton.Add_Click({
        $serviceLevel = $serviceLevelComboBox.SelectedItem
        $retentionCopy = $retentionComboBox.SelectedItem
        $offsiteCopy = $offsiteCheckBox.Checked
        $csvFilePath = $csvTextBox.Text

        if (Test-Path $csvFilePath) {
            $csvData = Import-Csv -Path $csvFilePath
            $token = Get-Token
            foreach ($row in $csvData) {
                $vmName = $row.VM_Name
                $tenant = $row.Tenant
                Write-Host "Processing VM: $vmName, Tenant: $tenant" -ForegroundColor Yellow
                $targetuuid = Get-TargetUUID -tenant $tenant
                if($tenant -ne "CCL COM SWAT AUTOMATION (TRIAL)"){
                Write-host "Hitting Reassign api" -ForegroundColor White
                Reassign-User -username $username -email $email -targetuuid $targetuuid
                $token = Get-Token
                  $server = "rvrci2sqlav2.vdc.nz"
                  $database = "master"
        
  $query = @"
        SELECT
            [UUID],
            [VMName]
        FROM 
            [ReveraSI_prod].[Compute].[Machine] 
        WHERE 
            [VMName] LIKE '%$vmName%' AND [active] = 1
"@
      

        $conn = Invoke-SQLCmd -Query $query -ServerInstance $server -Database $database -Encrypt Optional  
        $uuid = $conn.UUID.Guid
                $body = @{
    "machineGuid" = $uuid
    "cloudGuid" = $targetuuid
}
$headers = @{
    "Accept" = "application/json"
    "Authorization" = $token
    }
$snapresponse = Invoke-WebRequest -Uri "https://reveraapi-prod.vdc.nz/api/VirtualMachine/Actions" -Body $body -Headers $headers -Method get
$snapresponse=($snapresponse.Content)|ConvertFrom-Json
$snapshotRequest = $snapresponse | Where-Object { $_.Action -eq "snapshot_request" }
$snapshotDelete = $snapresponse | Where-Object { $_.Action -eq "snapshot_delete" }

# Check if "snapshot_request" is enabled and "snapshot_delete" is disabled
if ($snapshotRequest.Enabled -eq $true -and $snapshotDelete.Enabled -eq $false) {
  write-host "conditions met ,backup process"
   #Enable-Backup -vmName $vmName -serviceLevel $serviceLevel -retentionCopy $retentionCopy -offsiteCopy $offsiteCopy -targetuuid $targetuuid -token $token -tenant $tenant
    }
  elseif ($snapshotRequest.Enabled -eq $false -and $snapshotDelete.Enabled -eq $true){
  write-host "snapshot exists"
  }
  else{
  write-host "snapshot created outside portal"
  }
                }
            }
        } else {
            Write-Host "CSV file not found" -ForegroundColor Red
        }
    })

    # Event handlers
   $failedvm = @()

    $disableButton.Add_Click({
        $serviceLevel = $serviceLevelComboBox.SelectedItem
        $retentionCopy = $retentionComboBox.SelectedItem
        $offsiteCopy = $offsiteCheckBox.Checked
        $csvFilePath = $csvTextBox.Text

        if (Test-Path $csvFilePath) {
            $csvData = Import-Csv -Path $csvFilePath
            $token = Get-Token
            foreach ($row in $csvData) {
                $vmName = $row.VM_Name
                $tenant = $row.Tenant
                $targetuuid = Get-TargetUUID -tenant $tenant
                 Write-Host "Processing VM: $vmName, Tenant: $tenant" -ForegroundColor Yellow
                 if($tenant -ne "CCL COM SWAT AUTOMATION (TRIAL)"){
                Write-host "Hitting Reassign api" -ForegroundColor White
                Reassign-User -username $username -email $email -targetuuid $targetuuid
                $token = Get-Token
                  $server = "rvrci2sqlav2.vdc.nz"
                  $database = "master"
        
  $query = @"
        SELECT
            [UUID],
            [VMName]
        FROM 
            [ReveraSI_prod].[Compute].[Machine] 
        WHERE 
            [VMName] LIKE '%$vmName%' AND [active] = 1
"@
      

        $conn = Invoke-SQLCmd -Query $query -ServerInstance $server -Database $database -Encrypt Optional  
        $uuid = $conn.UUID.Guid
        # Get today's date
$today = Get-Date

# Subtract 7 days
$pastDate = $today.AddDays(-7)

# Format the date in yyyy-M-d format
$formattedDate = $pastDate.ToString("yyyy-M-d")

# Output the formatted date
$formattedDate


                  $body = @{
    "startDate" = $formattedDate
}
$headers = @{
    "Accept" = "application/json"
    "x-app-tenant-uuid" = $targetuuid
    "Authorization" = $token
}
$statresponse = Invoke-WebRequest -Uri "https://reveraapi-prod.vdc.nz/api/Backup/GetVirtualMachineBackupDetailsList/vmware/$uuid" -Body $body -Headers $headers
$statresponse=($statresponse.Content)|ConvertFrom-Json
$statresponse
$count=$statresponse.Jobs.Count
if($statresponse.Jobs[$count-1].JobStatus -eq 'completed'){
                Write-host "all good"
                Disable-Backup -vmName $vmName -serviceLevel $serviceLevel -retentionCopy $retentionCopy -offsiteCopy $offsiteCopy -targetuuid $targetuuid -token $token -tenant $tenant
                }
                else{
                     $failedvm += ", $vmName"
                    write-host "Bckup job not complete for $vmName"
                    
            }
            }
            }
        } else {
            Write-Host "CSV file not found" -ForegroundColor Red
        }
         Write-Host "VMs with incomplete backup jobs: $($failedvm -join ', ')" 
    })

   

    # Show the form
    [void]$form.ShowDialog()
}

# Show the backup form
Show-BackupForm

<#$body = @{
    "machineGuid" = $uuid
    "cloudGuid" = $targetuuid
}
$headers = @{
    "Accept" = "application/json"
    "Authorization" = $token
    }
$snapresponse = Invoke-WebRequest -Uri "https://reveraapi-prod.vdc.nz/api/VirtualMachine/Actions" -Body $body -Headers $headers -Method get
$snapresponse=($snapresponse.Content)|ConvertFrom-Json
$snapshotRequest = $snapresponse | Where-Object { $_.Action -eq "snapshot_request" }
$snapshotDelete = $snapresponse | Where-Object { $_.Action -eq "snapshot_delete" }

# Check if "snapshot_request" is enabled and "snapshot_delete" is disabled
if ($snapshotRequest.Enabled -eq $true -and $snapshotDelete.Enabled -eq $false) {
  write-host "conditions met ,backup process"
   Enable-Backup -vmName $vmName -serviceLevel $serviceLevel -retentionCopy $retentionCopy -offsiteCopy $offsiteCopy -targetuuid $targetuuid -token $token -tenant $tenant
    }
  elseif ($snapshotRequest.Enabled -eq $false -and $snapshotDelete.Enabled -eq $true){
  write-host "snapshot exists"
  }
  else{
  write-host "snapshot created outside portal"
  }#>
  
  <#$body = @{
    "startDate" = "2024-7-4"
}
$headers = @{
    "Accept" = "application/json"
    "x-app-tenant-uuid" = $targetuuid
    "Authorization" = $token
}
$response = Invoke-WebRequest -Uri "https://reveraapi-prod.vdc.nz/api/Backup/GetVirtualMachineBackupDetailsList/vmware/$uuid" -Body $body -Headers $headers#>
