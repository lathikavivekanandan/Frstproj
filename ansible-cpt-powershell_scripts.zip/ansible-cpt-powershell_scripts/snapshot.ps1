$filelocation ="C:\Software\SqlServer\22.2.0\SqlServer.psm1"
$filelocation1 ="‪C:\Software\SqlServer\22.2.0\SqlNotebook.psm1"
Import-Module $filelocation

$csv = Import-Csv -Path 'C:\Users\lvivekanandan\Desktop\test.csv'

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12



[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12

add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
 Write-host "successfully imported Modules and assembly required to perform the operation" -ForegroundColor White
# Define the API endpoint
$apiUrl = "https://IdentityService-prod.vdc.nz/oauth2/token"
$apiurl_cart="https://swat-wpd-id-cart-com-prod.vdc.nz/connect/token"
$username="lathika.com.auto"

$securePassword = Get-Content "C:\users\lvivekanandan\desktop\encrypted_password.txt" | ConvertTo-SecureString
$password = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword))
$body = @{
    grant_type = "password"
    client_id = "325E6995-2234-42C7-95FF-B9006FEADCF3"
    username = $username
    password = $password
}
$headers = @{
    "Content-Type" = "application/x-www-form-urlencoded"
}

$response = Invoke-RestMethod -Uri $apiUrl -Method Post -Headers $headers -Body $body
$token = $response.access_token
write-host "Generated token for Revera api" -ForegroundColor White
$headers_cart = @{
    "Accept" = "*/*"
    "Accept-Encoding" = "gzip, deflate"
    "Cache-Control" = "no-cache, no-cache"
    "Host" = "swat-wpd-id-cart-com-prod.vdc.nz"
    "Postman-Token" = "02b8a613-5050-4365-bae2-5f7d6e26b7f1,5bceed52-98a7-4e6b-bd75-c85bd1ba11d4"
}
$body_cart = @{
    "client_id" = "58cdeb3a-9492-4329-a2b6-a8046cf0451b"
    "client_secret" = "92837ca777ea4210bab578e568b6dd49ba93e00801804a60b675d9ce0130d73b"
    "grant_type" = "client_credentials"
    "user_name" = "lvivekanandan"
    "email_address" = "lathika.vivekanandan@concepts.co.nz"
    "first_name" = "firstname"
    "last_name" = "lastname"
    "idp" = "http://adfs.revera.co.nz/adfs/services/trust"
    "security_groups" = "| SWAT Team |"
    "mobile_number" = ""
}
$response = Invoke-WebRequest -Uri "https://swat-wpd-id-cart-com-prod.vdc.nz/connect/token" `
    -Method Post `
    -Headers $headers_cart `
    -ContentType "application/x-www-form-urlencoded" `
    -UserAgent "PostmanRuntime/7.16.3" `
    -Body $body_cart


$accessToken = ($response.Content | ConvertFrom-Json).access_token.Trim()
write-host "Generated token for Cart api" -ForegroundColor White

foreach ($row in $csv) {
  # Extract the VM name from the current row
  $vmName = $row.'VM Name'
  $ten=$tenant
  $tenant= $row.'Tenant'
  if ($tenant -eq ''){
  $tenant=$ten
  }

    
$server = "rvrci2sqlav2.vdc.nz"
$database = "master"
$query = @"
SELECT
    [UUID],
    [VMName]
FROM 
    [ReveraSI_prod].[Compute].[Machine] 
WHERE 
    [VMName] LIKE '%$vmname%' AND [active] = 1 
"@


$reassignquery= @"
SELECT
    [UUID],
    [Name] 
    FROM 
     [ReveraSI_prod].[dbo].[tblCustomer] 
WHERE 
    [Name] LIKE '%$tenant%' 
"@


# Connect to the database
$conn=Invoke-SQLCmd -Query $query -ServerInstance $server -Database $database  -Encrypt Optional  
$uuid= $conn.UUID.Guid

$reassignconn= Invoke-SQLCmd -Query $reassignquery -ServerInstance $server -Database $database  -Encrypt Optional
$targetuuid=$reassignconn.UUID.Guid
write-host "Connected with database and fetched the details successfully for $vmname" -ForegroundColor White
if($tenant -ne "CCL COM SWAT AUTOMATION (TRIAL)"){
Write-host "Hitting Reassign api" -ForegroundColor White
$url = 'https://swat-wpd-api-cart-com-prod.vdc.nz/Tenancy/api/User/ReassignCCUserAccount'
$headers_reassign = @{
    "accept" = "text/plain"
    "Authorization" = "Bearer $accessToken"
    "Content-Type" = "application/json-patch+json"
}



# Output the response

# Define the URL and headers


# Define the JSON body
$body_reassign = @{
    ccUserGuid = "7C3CC961-BF59-4B67-BE19-55EF6DB745E4"
    emailAddress = "lathika.vivekanandan@concepts.co.nz"
    ccUserName = $username
    supportTicket = ""
    currentCustomerGuid = "8AACB639-4B56-4C70-87E4-FA995B8EE50E"
    firstName = ""
    mobileNumber = ""
    currentCustomerName = "CCL COM SWAT AUTOMATION (TRIAL)"
    cartUserName = "lVivekanandan"
    lastName = ""
    targetCustomerGuid = $targetuuid
    isAogUser = $false
    roles = $null
} | ConvertTo-Json

# Make the POST request
$response_reassign = Invoke-RestMethod -Uri $url -Method Post -Headers $headers_reassign -Body $body_reassign

# Output the response


  if ($response_reassign -eq "True"){
    write-host "Reassigned the user successfully " -ForegroundColor Green
    }
    else{
    Write-Host "some error occured when reassigning " -ForegroundColor Red
    
    }
    }
    

  $apiHeaders = @{
        "Authorization" = "$token"
        "Accept" = "text/plain"
    }

$apiUrl = "https://reveraapi-prod.vdc.nz/api/VirtualMachine/DoAction?machineGuid=$uuid&action=snapshot_delete"

    # Define the headers for the API request
   

    # Make the POST request to perform the action
    $apiResponse = Invoke-restmethod -Uri $apiUrl -Method Post -Headers $apiHeaders

    # Output the API response
    if ($apiResponse -eq "success"){
    write-host "Snapshot deleted Successfully for $vmname " -ForegroundColor Green
    }
    else{
    Write-Host "some error occured when processing for $vmname" -ForegroundColor Red
    
    }
    $apiresponse=""
    }
