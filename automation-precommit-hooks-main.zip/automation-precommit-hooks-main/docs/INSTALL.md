# Installation
The following instructions should be carried out within the root directory of you cloned copy of `ansible-prod`.  The installation deploys pre-commit managed commit hook in `.git/hooks/pre-commit`
1. `pip3 install pre-commit --user`
2. from `ansible-prod` local repository. `pre-commit install`.

# Usage
[Find instructions here](https://gitlab.com/ComputerConceptsLimited/pre-commit-hooks/blob/master/docs/USAGE.md)
