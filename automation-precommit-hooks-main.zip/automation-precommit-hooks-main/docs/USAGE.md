# Using pre-commit-hooks with ansible-prod
Add this to `.pre-commit-config.yaml`, this file is already in the ansible-prod repository.

```
- repo: git@github.com:ComputerConceptsLimited/ccl-pre-commit-hooks.git
rev: 1.0.0
hooks:
    - id: vlan-duplicates
    - id: vlan-keys
    - id: vlan-tags-exist
    - id: fmg-client-variables
    - id: jinja2-lint
    - id: ansible-lint
    - .....
    - .....
```

# CLI
Good resource can be found [here](https://pre-commit.com/#usage)
