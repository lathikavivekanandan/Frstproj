# !/usr/bin/env python3
#  -*- coding: utf-8 -*-
# maintainer (@LaoZhuBaba)
"""
Check consistency between the vlans.yml data and vlan_lookup.yml.  This relates to the ucsc_tags field
(or whatever TAG_FIELD is set to) within vlans.yml which is a list of tags which are used to look up
data within vlan_lookup.yml.

Unlike most pre-commit checks, this checking is about consistency BETWEEN two files, to if either of
file is changed we need to compare with the other file.  These files are not located in the same
directory, and the diretory structure has varied slightly over time and has in some cases been
different between Prod and PreProd.
"""
import sys
import yaml

from hooks.functions.common_functions import get_site_code
from hooks.functions.common_functions import message_logging

TAG_FIELD = "ucsc_tags"


def find_pair_file(filename):
    """
    Code the logic to find the missing partner of either file: locate vlans.yml if we are passed vlan_lookup.yml
    or vice versa.
    """
    basedir, middledir, shortfilename = filename.rsplit("/", 2)
    if shortfilename == "vlans.yml":
        pair_file = (
            filename,
            basedir + "/" + middledir + "_ucsc" + "/" + "vlan_lookup.yml",
        )
    elif shortfilename == "vlan_lookup.yml":
        pair_file = (
            basedir + "/" + middledir.removesuffix("_ucsc") + "/" + "vlans.yml",
            filename,
        )
    else:
        return False
    message_logging(
        level="INFO",
        filename=filename,
        message_title="Found pair for file",
        message=f"{pair_file}",
    )
    return pair_file


def check_dir(dir, vlans_yml, vlan_lookup_yml):
    """
    This is where the actual checking occurs.  We have been passed the name of a single
    YAML file.  We need to work out whether it is a "site_vlan" file, a "ucsc_tag_lookup"
    file or something else.  If it's something else then we ignore it.  For the other
    two options we need to find the matching pair.  I.e., if we have been passed a
    "site_vlan" file then we need to find its matching "ucsc_tag_lookup" file and vice
    versa.
    """

    try:
        with open(vlans_yml) as f:
            vlans_dict = yaml.full_load(f)
        with open(vlan_lookup_yml) as f:
            vlan_lookup_dict = yaml.full_load(f)

        # The vlans_yml file should contain a single dictionary called 'site_vlans'
        if list(vlans_dict.keys()) != ["site_vlans"]:
            raise ValueError(
                f"The vlans_yml file for site {dir} doesn't contain only a site_vlans" " dictionary",
                vlans_yml,
            )
        # vlans_lookup_yml file should contain only a single dictionary called 'ucsc_tag_lookup'
        if list(vlan_lookup_dict.keys()) != ["ucsc_tag_lookup"]:
            raise ValueError(
                f"The vlan_lookup_yml file for site {dir} doesn't contain only a" " ucsc_tag_lookup dictionary",
                vlan_lookup_yml,
            )

        # Iterate through each VLAN in the file and perform various checks...
        for vlan in vlans_dict["site_vlans"]:
            vlan_name = vlan.get("vlan_name", "Name Not found")
            vlan_keys = vlan.keys()
            if TAG_FIELD not in vlan_keys:
                # This is not an error.  It just means that there are VLAN entries which are not
                # relevant to UCSC so we can skip the checks
                # print(f"Info: VLAN {vlan.get('vlan_name', 'No VLAN Name')} has no {TAG_FIELD} field")
                continue
            # Check if all the tags link to valid keys in the lookup dictionary.
            for tag in vlan[TAG_FIELD]:
                if tag not in vlan_lookup_dict["ucsc_tag_lookup"].keys():
                    raise ValueError(
                        f"VLAN {vlan['vlan_name']} for site {dir} has {TAG_FIELD} field:"
                        f" {tag} with no matching entry in vlan_lookup_dict",
                        vlan_lookup_yml,
                    )

            # In our case there may only be one tag in the list means that a single lookup must
            # find both the required "vnic_templates" and "vlan_domain_group" data, with the
            # the right types.
            if len(vlan[TAG_FIELD]) == 1:
                if not isinstance(
                    vlan_lookup_dict["ucsc_tag_lookup"][vlan[TAG_FIELD][0]].get(
                        "vlan_domain_group",
                        False,
                    ),
                    str,
                ):
                    raise TypeError(
                        f"VLAN: {vlan_name} for site {dir}" " refers to a vlan_domain_group which is not a string",
                        vlans_yml,
                    )
                if not isinstance(
                    vlan_lookup_dict["ucsc_tag_lookup"][vlan[TAG_FIELD][0]].get(
                        "vnic_templates",
                        None,
                    ),
                    (list, type(None)),
                ):
                    raise TypeError(
                        f"VLAN: {vlan_name} for site {dir} refers to a vnic_template" " which is not a list or None",
                        vlans_yml,
                    )

            # The other legitimate case is that there may be two tags, with one referring to a
            # "vlan_domain_group" key and the other to a "vnic_templates key"
            elif len(vlan[TAG_FIELD]) == 2:
                # The logic here is a bit ugly but we need to find a single occurence of
                # "vlan_domain_group" and a single occurence of "vnic_templates" but we don't
                # know which will come first.  So just get a true of false value for each
                # of four combinations.
                index0_vnt = vlan_lookup_dict["ucsc_tag_lookup"][vlan[TAG_FIELD][0]].get(
                    "vnic_templates",
                    False,
                )
                index0_vdg = vlan_lookup_dict["ucsc_tag_lookup"][vlan[TAG_FIELD][0]].get(
                    "vlan_domain_group",
                    False,
                )
                index1_vnt = vlan_lookup_dict["ucsc_tag_lookup"][vlan[TAG_FIELD][1]].get(
                    "vnic_templates",
                    False,
                )
                index1_vdg = vlan_lookup_dict["ucsc_tag_lookup"][vlan[TAG_FIELD][1]].get(
                    "vlan_domain_group",
                    False,
                )

                if index0_vnt and index1_vdg:
                    if not isinstance(index0_vnt, (list, type(None))) and isinstance(index1_vdg, str):
                        raise TypeError(
                            f"VLAN: {vlan_name} for site {dir} has tags referring to data" " of the wrong type",
                            vlans_yml,
                        )
                    if index1_vnt or index0_vdg:
                        raise ValueError(
                            f"VLAN: {vlan_name} for site {dir} has tags with overlapping" " values",
                            vlans_yml,
                        )
                elif index1_vnt and index0_vdg:
                    if not isinstance(index1_vnt, (list, type(None))) and isinstance(index0_vdg, str):
                        raise TypeError(
                            f"VLAN: {vlan_name} for site {dir} has tags referring to data" " of the wrong type",
                            vlan_lookup_yml,
                        )
                    if index0_vnt or index1_vdg:
                        raise ValueError(
                            f"VLAN: {vlan_name} for site {dir} has tags with overlapping" " values",
                            vlan_lookup_yml,
                        )
                else:
                    raise ValueError(
                        f"VLAN: {vlan_name} for site {dir} has two tags referring to the"
                        " wrong combination of types",
                        vlan_lookup_yml,
                    )
            else:
                raise ValueError(
                    f"VLAN: {vlan_name} for site {dir} has more than two tags",
                    vlans_yml,
                )
    except Exception as e:
        exc, filename = e.args
        msg = f"Exception {type(e).__name__} encountered in check_dir(): {exc}"
        message_logging(filename=filename, message=f"{msg}")
        return False
    else:  # This is on the try block.  I.e., return True if no exceptions are raised.
        return True


def main():
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    already_checked = []
    for arg in sys.argv[1:]:
        file_pair_duple = find_pair_file(arg)
        # We need to account for the fact that if both the vlan_lookup.yml file and the vlans.yml file
        # then both files will be in the argument list but we don't need to test the pair of files
        # twice.  So record the pair do a "continue" if the pair is already in the already_checked[] list.
        if file_pair_duple in already_checked:
            continue
        else:
            already_checked.append(file_pair_duple)
        if check_dir(get_site_code(arg), *file_pair_duple):
            continue
        # As soon as there is a single failure we return False
        print("Returning False")
        return False
        sys.exit(1)
    # If we've reached here then there have been no failures
    print("Returning True")
    #    return True
    sys.exit(0)


if __name__ == "__main__":
    main()
