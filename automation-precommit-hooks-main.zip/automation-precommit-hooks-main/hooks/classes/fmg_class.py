#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
class used to validate esp details
"""
import netaddr
import yaml
from netaddr import IPNetwork

from hooks.config.fmg_clients import CLIENT_ALLOWED_KEYS
from hooks.config.fmg_clients import CLIENT_DATA_TYPES
from hooks.config.fmg_clients import CLIENT_MINIMAL_KEYS
from hooks.config.fmg_clients import CLUSTER_NAMES
from hooks.config.fmg_clients import FAZ_PRESETS
from hooks.config.fmg_clients import INTERFACE_ALLOWED_KEYS
from hooks.config.fmg_clients import INTERFACE_DATA_TYPES
from hooks.config.fmg_clients import INTERFACE_MINIMAL_KEYS
from hooks.config.fmg_clients import SERVICE_OPTIONS
from hooks.config.fmg_clients import VDOM_NAME_MAX_LENGTH
from hooks.config.fmg_clients import VLAN_NAME_MAX_LENGTH
from hooks.functions.common_functions import check_keys
from hooks.functions.common_functions import message_logging
from hooks.functions.common_functions import string_length
from hooks.functions.common_functions import vlan_check

DOCUMENTATION = """
"""

REQUIREMENTS = """
  - netaddr
  - PyYaml
"""


class FmgClientTests(object):
    """
    Class with methods for validating esp_clients.yml
    """

    def __init__(self, **kwargs):
        """
        params:
            kwargs:
                filename: Path to esp_clients.yml
        """
        self.error = False
        self.filename = kwargs.get("filename")
        self.clients = self.get_clients()
        self.client_interfaces = self.get_clients()[0]["interfaces"]

    def run_tests(self) -> tuple:
        """
        Main method called by hook scripts.
        Returns: tuple(
            bool(self.error),
            list(self.messages)
        )
        """
        self.validate_client_instance()
        self.validate_interface_instance()

        for client in self.clients:
            self.validate_keys(
                allowed=CLIENT_ALLOWED_KEYS,
                minimal=CLIENT_MINIMAL_KEYS,
                data=client,
            )
            if "vdomname" in client:
                self.validate_string_length(
                    key_name="vdomname",
                    key_data=client["vdomname"],
                    length=VDOM_NAME_MAX_LENGTH,
                )
            self.verify_ip_routed(client)
            self.validate_service_option(client)
            self.validate_cluster_name(client)
            self.validate_faz_preset(client)

            for interface in self.client_interfaces:
                self.validate_keys(
                    allowed=INTERFACE_ALLOWED_KEYS,
                    minimal=INTERFACE_MINIMAL_KEYS,
                    data=interface,
                )
                if "vlan_name" in interface:
                    self.validate_string_length(
                        key_name="vlan_name",
                        key_data=interface["vlan_name"],
                        length=VLAN_NAME_MAX_LENGTH,
                    )
                self.validate_interface_tags(interface)
                self.validate_vlans(interface)

        return self.error

    def set_error_true(self) -> bool:
        """
        Sets self.error
        """
        try:
            self.error = True if self.error is not True else self.error
            return True
        except Exception:
            raise ("Problem with 'set_error_true()")

    def get_clients(self) -> list:
        """
        Returns a list for clients and their attributes.
        """
        with open(self.filename) as f:
            esp_clients = yaml.load(f, Loader=yaml.FullLoader)["esp_clients"]

        return esp_clients

    def validate_keys(self, **kwargs) -> None:
        """
        Validate  minimal and allowed keys for a data model.
        params:
            kwargs:
                allowed: List of allowed Keys
                minimal: List of minimal Keys
                data: Dictionary to validate
        sets: self.error
        Returns: None
        """
        # Define the KEY LISTS
        ALLOWED_KEYS = kwargs.get("allowed")
        MINIMAL_KEYS = kwargs.get("minimal")
        data = kwargs.get("data")

        # Check minimal keys
        error, results = check_keys(
            filename=self.filename,
            authoritive_keys=MINIMAL_KEYS,
            validate_keys=data.keys(),
            check_type="minimal",
        )
        if error is True:
            self.set_error_true()
            message_logging(
                filename=results["filename"],
                message_title=results["message_title"],
                message=f"{results['message']}",
            )

        # Check allowed keys
        error, results = check_keys(
            filename=self.filename,
            authoritive_keys=ALLOWED_KEYS,
            validate_keys=data.keys(),
            check_type="allowed",
        )
        if error is True:
            self.set_error_true()
            message_logging(
                filename=results["filename"],
                message_title=results["message_title"],
                message=f"{results['message']}",
            )

        return None

    def validate_client_instance(self) -> None:
        """
        Verify the client keys/values are of the correct instance class type.
        params:
            self.clients: clients and their attributes
        sets: self.error
        Returns: None
        """
        # print(json.dumps(self.clients, indent=4))
        for client in self.clients:
            for k, v in client.items():
                try:
                    # ensure router_id is converted to correct class, defaults to type(str)
                    v = IPNetwork(v) if k == "router_id" else v
                    # Check the class type of client data (v) sgainst dict with accepted types
                    if k in CLIENT_DATA_TYPES and not isinstance(
                        v,
                        CLIENT_DATA_TYPES[k],
                    ):
                        raise TypeError

                except (netaddr.core.AddrFormatError, TypeError):
                    self.set_error_true()
                    message_logging(
                        filename=self.filename,
                        message_title="Invalid Data Type",
                        message=f"Recieved class type {type(v)} for key {k}, expected {CLIENT_DATA_TYPES[v]}",
                    )

        return None

    def validate_interface_instance(self) -> None:
        """
        Verify the client interface keys/values are of the correct instance class type.
        params:
            self.client_interfaces: clients interfaces and their attributes
        sets: self.error
        Returns: None
        """
        for interface in self.client_interfaces:
            for k, v in interface.items():
                try:
                    # ensure ip_address is converted to correct class, defaults to type(str)
                    v = IPNetwork(v) if k == "ip_address" else v
                    # Check the class type of client data (v) sgainst dict with accepted types
                    if k in INTERFACE_DATA_TYPES and not isinstance(
                        v,
                        INTERFACE_DATA_TYPES[k],
                    ):
                        raise TypeError

                except (netaddr.core.AddrFormatError, TypeError):
                    self.set_error_true()
                    message_logging(
                        filename=self.filename,
                        message_title="Invalid Data Type",
                        message=f"Recieved class type '{type(v)}' for key '{k}', expected {INTERFACE_DATA_TYPES[k]}",
                    )

        return None

    def verify_ip_routed(self, client=None) -> None:
        """
        Validates an IP address is valid.
        Appends to REPORT as errors are found
        params:
            client: Single client dict
        sets: self.error
        Returns: None
        """
        if "routedSpacev4" in client:
            for ip in client["routedSpacev4"]:
                try:
                    if not isinstance(IPNetwork(ip), netaddr.ip.IPNetwork):
                        raise TypeError

                except (netaddr.core.AddrFormatError, TypeError):
                    self.set_error_true()
                    message_logging(
                        filename=self.filename,
                        message_title="Invalid Data Type",
                        message=f"Recieved class type {type(ip)} for key routedSpace, expected {netaddr.ip.IPNetwork}, client_name: {client['name']}",
                    )

        if "routedSpacev6" in client:
            for ip in client["routedSpacev6"]:
                try:
                    if not isinstance(IPNetwork(ip), netaddr.ip.IPNetwork):
                        raise TypeError

                except (netaddr.core.AddrFormatError, TypeError):
                    self.set_error_true()
                    message_logging(
                        filename=self.filename,
                        message_title="Invalid Data Type",
                        message=f"Recieved class type {type(ip)} for key routedSpace, expected {netaddr.ip.IPNetwork}, client_name: {client['name']}",
                    )

        return None

    def validate_interface_tags(self, interface=None) -> None:
        """
        Validates self.interface["tags"]
        params:
            interface: Single interface entry dict
        sets: self.error
        Returns: None
        """
        ALLOWED_TAGS = [
            "wan",
            "internet",
            "primary",
            "secondary",
            "tertiary",
            "quaternary",
            "other",
        ]

        if "tags" in interface:
            for tag in interface["tags"]:
                if tag not in ALLOWED_TAGS:
                    self.set_error_true()
                    message_logging(
                        filename=self.filename,
                        message_title="Bad Tag Detected",
                        message=f"Bad Tag '{tag}' found on '{interface['vlan_name']}', allowed tags: {ALLOWED_TAGS}",
                    )

        return None

    def validate_vlans(self, interface=None) -> None:
        """
        Checks that the passed in VLAN ID is a valid integer
        and from the valid permisible range.
        params:
            interface: Single interface entry dict
        sets: self.error
        Returns: None
        """
        for interface in self.client_interfaces:
            if "vlan_id" in interface:
                if vlan_check(interface["vlan_id"]) is False:
                    self.set_error_true()
                    message_logging(
                        filename=self.filename,
                        message_title="Bad VLAN ID Detected",
                        message=f"received {interface['vlan_id']} on {interface}",
                    )

        return None

    def validate_string_length(self, **kwargs) -> None:
        """
        Checks the length of adom or vdom name string.
        params:
            kwrargs:
                key_name: Key being validated
                key_data: Key data
                length: max length of key data
        sets: self.error
        Returns: None
        """
        key_name = kwargs.get("key_name")
        key_data = kwargs.get("key_data")
        length = kwargs.get("length")

        if string_length(key_data, length) is False:
            self.set_error_true()
            message_logging(
                filename=self.filename,
                message_title="Bad String Length Detected",
                message=f"Length of '{key_data}' exceeds '{length}' in '{key_name}'",
            )

        return None

    def validate_service_option(self, client: str = None) -> None:
        """
        Checks the service_otion is from the permitted list.
        params:
            client: Single client dict
        sets: self.error
        Returns: None
        """
        if client["service_option"].lower() not in SERVICE_OPTIONS:
            self.set_error_true()
            message_logging(
                filename=self.filename,
                message_title="Bad service_option Detected",
                message=f"service_option '{client['service_option']}', allowed options: {SERVICE_OPTIONS}",
            )

        return None

    def validate_cluster_name(self, client: str = None) -> None:
        """
        Checks the CLUSTER_NAMES is from the permitted list.
        params:
            client: Single client dict
        sets: self.error
        Returns: None
        """
        if client["cluster"].lower() not in CLUSTER_NAMES:
            self.set_error_true()
            message_logging(
                filename=self.filename,
                message_title="Bad cluster_name Detected",
                message=f"cluster '{client['cluster']}', allowed options: {CLUSTER_NAMES}",
            )

        return None

    def validate_faz_preset(self, client: str = None) -> None:
        """
        Checks the service_otion is from the permitted list.
        params:
            client: Single client dict
        sets: self.error
        Returns: None
        """
        if client["faz_presets"].lower() not in FAZ_PRESETS:
            self.set_error_true()
            message_logging(
                filename=self.filename,
                message_title="Bad faz_presets Detected",
                message=f"faz_presets '{client['faz_presets']}', allowed options: {FAZ_PRESETS}",
            )

        return None
