#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Client data models
"""
import netaddr

# Setup global variables
# Client data models
CLIENT_ALLOWED_KEYS = [
    "name",
    "cluster",
    "adomname",
    "vdomname",
    "atnumber",
    "service_option",
    "faz_presets",
    "bgp_asn",
    "router_id",
    "interfaces",
    "routedSpacev4",
    "routedSpacev6",
]
CLIENT_MINIMAL_KEYS = CLIENT_ALLOWED_KEYS[:11]
CLIENT_DATA_TYPES = dict(
    name=str,
    cluster=str,
    adomname=str,
    vdomname=str,
    atnumber=str,
    service_option=str,
    faz_presets=str,
    bgp_asn=str,
    router_id=netaddr.ip.IPNetwork,
    interfaces=list,
    routedSpacev4=list,
    routedSpacev6=list,
)

# Interface data models
INTERFACE_ALLOWED_KEYS = [
    "vlan_name",
    "vlan_id",
    "ip_address",
    "tags",
    "ip6_address",
]
INTERFACE_MINIMAL_KEYS = INTERFACE_ALLOWED_KEYS[:4]
INTERFACE_DATA_TYPES = dict(
    vlan_name=str,
    vlan_id=int,
    tags=list,
    ip_address=netaddr.ip.IPNetwork,
    ip6_address=netaddr.ip.IPNetwork,
)

# Service/FAZ options
SERVICE_OPTIONS = ["Basic", "standard", "premium", "custom"]
FAZ_PRESETS = [
    "default",
    "standard",
    "advanced",
    "custom:1",
    "custom:2",
    "custom:3",
    "custom:4",
    "custom:5",
    "custom:6",
    "custom:7",
    "custom:8",
    "custom:9",
    "custom:10",
]

# Cluster Names
CLUSTER_NAMES = [
    "vcan-a03-fw",
    "vcan-a04-fw",
    "vcan-a04-fw03",
    "vcan-a04-fw04",
    "vcan-c00-fw",
    "vcan-c00-fw04",
    "vcan-d02-fw",
    "vcan-h00-fw",
    "vcan-n00-fw",
]
# TODO
# Need to write a dynamic function to queue fmg once we have remote runners

# Other attributes
VDOM_NAME_MAX_LENGTH = 11
VLAN_NAME_MAX_LENGTH = 16
