#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Handover data models
"""

ALLOWED_KEYS = dict(
    ONEARM=("type", "client_id", "interface", "description", "tags", "native", "speed", "state", "xlate"),
    MLAG=("type", "client_id", "members", "description", "portchannel", "tags", "native", "speed", "state", "xlate"),
)

MINIMAL_KEYS = dict(
    ONEARM=ALLOWED_KEYS["ONEARM"][:5],
    MLAG=ALLOWED_KEYS["MLAG"][:6],
)

FIELD_TYPES = dict(
    type=str,
    client_id=int,
    interface=str,
    description=str,
    tags=str,  # will be a list of strings test with `all(isinstance(x, str) for x in tags)`
    native=str,
    speed=str,
    portchannel=int,
    members=str,  # will be a list of strings test with `all(isinstance(x, str) for x in members)`
    state=str,
    xlate=dict,  # will be a list of strings test with `all(isinstance(x, dict) for x in members)`
)

FIELD_OPTIONS = dict(
    type=("client", "infrastructure", "service_provider", "colo_onearm_switch"),
    speed=("100full", "1000full", "10000full", "25gfull"),
    state=("shutdown", "no shutdown"),
)
