# !/usr/bin/env python3
#  -*- coding: utf-8 -*-
# maintainer (@pandanz)
"""
Ensure devcontainers and runners are setup correctly.
"""
from pathlib import Path
import sys
import os
import pkgutil

DOCUMENTATION = """
Ensures that files related to the devcontainers and runners exist.
If they do exist then no modifications are made, otherwise that templates are used to create
the required folders/files
"""

RETURNS = """
PASS/FAIL
Lists files that were modified or created.
"""

exec_required = [".devcontainer/entrypoint.sh"]


def _container_setup():
    """
    Inital entrypoint from __main__:
    Prints: files that were modified or created
    Returns: bool
    """
    error = False
    files = (
        (".devcontainer/devcontainer.json", "templates/devcontainer_json_template"),
        (".devcontainer/entrypoint.sh", "templates/devcontainer_entrypoint_template"),
        (".devcontainer/pip-requirements.txt", "templates/devcontainer_pip_template"),
    )

    files_modified = []

    for filename, template in files:
        file = Path(filename)
        content = pkgutil.get_data("hooks", template).decode()
        if not os.path.exists(filename):
            files_modified.append(filename)
            file.parent.mkdir(exist_ok=True, parents=True)
            file.touch(exist_ok=True)
            Path(filename).write_text(content)
            if filename in exec_required:
                file.chmod(0o755)

    if files_modified:
        for file in files_modified:
            print(f"{file} was not present, defaulting to standard")
        error = True

    return error


def main():
    """
    Checks local repo files exist or it will use the templates
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    error = False

    error = _container_setup()

    if error is True:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    sys.exit(main())
