#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Loads site handovers from groups_vars and host_vars and verifies
all configured MLAGs are unique
"""
import argparse
import sys
import traceback

from datetime import datetime
from hooks.functions.common_functions import get_site_code
from hooks.functions.common_functions import load_ansible_inventory
from hooks.functions.common_functions import message_logging

DOCUMENTATION = """
Loads site handovers from groups_vars and host_vars and verifies
all configured MLAGs are unique.
"""

RETURNS = """
PASS/FAIL
Dictionary containing errors.
"""


def _run_test(filename) -> bool:
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked
    Returns: bool
    """
    error = False
    interfaces = {}

    try:
        site = site = get_site_code(filename)
        inventory = load_ansible_inventory("hosts")
        host_vars = inventory["_meta"]["hostvars"]
        interfaces = _get_mlags(host_vars, site)
        error = _check_mlag_assignments(interfaces, site)

        return error

    except Exception as e:
        exc = "{} - {}: {}".format(datetime.now(), type(e).__name__, e)
        print("Something went wrong: {}".format(exc))
        traceback.print_exc()
        error = True
        pass


def _check_mlag_assignments(interfaces=None, site=None) -> bool:
    """
    Tests that MLAGs are all unique fo the site
    params:
       intefaces: list of interface names
       site: site code
    Returns: bool
    Comments: Prints results to stdout as part of test run.
    """
    error = False
    for host, interfaces in interfaces.items():
        processed = []
        reported = []
        for mlag in interfaces:
            if mlag in processed and mlag not in reported:  # only report an interface once
                message_logging(
                    filename=site,
                    message_title="Duplicate MLAG",
                    message=f"{host} '{mlag}' - Detected more than once, check MLAG assignments",
                )
                reported.append(mlag)
                error = True
            processed.append(mlag)

    return error


def _get_mlags(host_vars=None, site=None) -> dict:
    """
    params:
      host_vars: ansible host_vars from loaded inventory
      site: The site code
    returns: Dict of devices with their MLAGs
    """
    results = {}
    for host, data in host_vars.items():
        if ("ltr" in host or "lyc" in host) and site in host:
            results[host] = []
            if "mlag_handovers" in data:
                for handover in data["mlag_handovers"]:
                    for i in handover.values():
                        results[host].append(i["portchannel"])

    return results


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)
    error = False

    for filename in args.filenames:
        error = _run_test(filename) if error is not True else error

    try:
        return error
    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
