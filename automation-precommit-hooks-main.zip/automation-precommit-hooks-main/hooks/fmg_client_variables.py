#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
validation of group_vars/fortinet/esp_clients.yml data model
"""
import argparse
import sys

from hooks.classes.fmg_class import FmgClientTests

DOCUMENTATION = """
pytest for validation of group_vars/fortinet/esp_clients.yml data model.
The tests for valid dictionary keys and data types.
vdomname and adomname limiations are in place and are also tested by this script.
"""

REQUIREMENTS = """
pip3 install pytest netaddr argprase --user
pip3 install 'PyYAML>=5.1.2' --user
"""


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)
    error = False

    for filename in args.filenames:

        # instantiate the class
        error = FmgClientTests(filename=filename)

        # Run the tests and capture the returned values
        error = error.run_tests()

    try:
        return error
    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
