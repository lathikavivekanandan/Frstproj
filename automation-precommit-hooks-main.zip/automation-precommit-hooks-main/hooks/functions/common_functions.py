#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Common functions used by other modules
"""
import json
import subprocess
from logzero import logger
from git import Repo

VLAN_MIN = 2
VLAN_MAX = 4094


def tag_cleanup(site_tags=None, skip=None) -> list:
    """
    Method cleans up the list of tags.
    params:
        site_tags: List of tags
    Return: list of unique tags
    """
    return [tag for tag in site_tags if skip is not None and tag not in skip]


def get_site_code(filename: str) -> str:
    """
    Discovers site_code from the filename
    Return String
    """
    if "host_vars" in filename:
        site_code = filename.split("/")[-1].split("-")[1]
    elif "group_vars in filename":
        site_code = filename.split("/")[-2].split("_")[0]

    return site_code


def vlan_check(vlan_id: int, result=True) -> bool:
    """
    Checks the validity of the passed vlan_id: int.
    Returns: bool
    params:
        vlan_id: int: VLAN ID between 2-4094
    """
    return True if vlan_id >= VLAN_MIN and vlan_id <= VLAN_MAX else False


def string_length(string: str, length: int, result=True) -> bool:
    """
    Checks the passed string is equal to or less than the passed in length.
    Returns: bool
    params:
        string: the string to test.
        length: the max length of the string.
    """
    return True if len(string) <= length else False


def message_logging(**kwargs) -> None:
    """
    Takes the inputs and print logging message to stdout
    params:
        kwargs:
            level: Indicated level (default = ERR)
            filename: Name of the file tested.
            message_title: Title of the message
            message: Message
            data: Any associated data that helps with identification
    Returns: None
    """

    level = kwargs.get("level") if "level" in kwargs else "ERR"
    filename = kwargs.get("filename")
    message_title = kwargs.get("message_title")
    message = kwargs.get("message")
    data = kwargs.get("data") if "data" in kwargs else None

    logger.error(f"[{level}] {filename} - {message_title}: {message}")
    if data is not None:
        logger.debug(f"[Error Data]: {data}")

    return None


def check_keys(**kwargs) -> tuple:
    """
    Checks the data_keys against the passed in key_list.
    params:
        kwargs:
            filename: Name of the file tested
            authoritive_keys: Keys to valididate against the model.
            validate_keys: Keys from the passed in data model.
            check_type: either "minimal" or "allowed"
    Returns: tuple
    Also: Print messages to stdout
    """
    error = False
    message = ""

    filename = kwargs.get("filename")
    authoritive_keys = kwargs.get("authoritive_keys")
    validate_keys = kwargs.get("validate_keys")
    check_type = kwargs.get("check_type")

    if check_type == "minimal":
        message_title = "Missing Keys"

    elif check_type == "allowed":
        message_title = "Invalid Keys"

    # check for minimal keys
    if message_title == "Missing Keys":
        try:
            if not set(authoritive_keys).issubset(validate_keys):
                raise KeyError
        except KeyError:
            message = dict(
                filename=filename,
                message_title=message_title,
                message=list(set(authoritive_keys) - set(validate_keys)),
            )
            error = True

    # check for allowed keys
    elif message_title == "Invalid Keys":
        try:
            for key in validate_keys:
                if key not in authoritive_keys:
                    raise KeyError
        except KeyError:
            message = dict(
                filename=filename,
                message_title=message_title,
                message=list(set(validate_keys) - set(authoritive_keys)),
            )
            error = True

    return error, message


def load_ansible_inventory(inventory_file=None) -> dict:
    """
    params:
      inventory_file: ini or yaml inventory file
    returns: Pythony dictionary
    """

    inventory = subprocess.run(
        [
            "ansible-inventory",
            "-i",
            inventory_file,
            "--list",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )
    inventory = json.loads(inventory.stdout.decode("utf-8"))
    return inventory


def get_changed_files_from_master() -> list:
    """
    Returns a list of changed files, comparing master to current branch
    """
    current_branch = subprocess.check_output("git rev-parse --abbrev-ref HEAD", shell=True).decode("utf8")
    files_changed = subprocess.check_output(
        f"git diff-tree --no-commit-id --name-only -r origin/master -r {current_branch}", shell=True
    ).decode("utf8")
    files_changed = [x.strip() for x in files_changed.split("\n")]  # covert multiline string to list
    return files_changed


def get_master_file(filename) -> str:
    """
    Returns the master version of the changed file
    This will be a multiline YAML file
    Calling line should use yaml.load() function to parse into dict or list
    """
    repo = Repo()
    assert not repo.bare
    index = repo.index
    # loop through modified files, looking for filename
    # capture the b_blob as the reference data
    for x in index.diff("master").iter_change_type("M"):
        # find our file
        if filename == x.b_rawpath.decode("utf-8"):
            # return the text blob for this file
            return x.b_blob.data_stream.read().decode("UTF-8")
