#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Loads site handovers from groups_vars and host_vars and verifies
all configured interfaces have client_id field
"""

import argparse
from typing import Optional
from typing import Sequence

import yaml

DOCUMENTATION = """
Loads site handovers from groups_vars and host_vars and verifies
all configured interfaces have client_id field.
"""

RETURNS = """
PASS/FAIL
Lists yaml dictionaries with missing client_id field.
"""


def main(argv: Optional[Sequence[str]] = None) -> int:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)

    retval = 0
    for filename in args.filenames:
        with open(filename, "rb") as f:
            try:
                yamldata = yaml.load(f, Loader=yaml.FullLoader)
                for m_handovers in yamldata.get("mlag_handovers", []):
                    for key, val in m_handovers.items():
                        if "client_id" not in val:
                            print(
                                "{} is missing client_id field in file {}".format(
                                    key,
                                    filename,
                                ),
                            )
                            retval = 1
                for s_handovers in yamldata.get("single_handovers", []):
                    for key, val in s_handovers.items():
                        if "client_id" not in val:
                            print(
                                "{} is missing client_id field in file {}".format(
                                    key,
                                    filename,
                                ),
                            )
                            retval = 1
            except Exception as exc:
                print(f"{filename}: Failed to yaml decode ({exc})")
                retval = 1

    return retval


if __name__ == "__main__":
    exit(main())
