#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Validation of handover data models
"""
import argparse
import sys
import yaml
from datetime import datetime
import traceback
from hooks.config.handovers import (
    ALLOWED_KEYS,
    MINIMAL_KEYS,
    FIELD_TYPES,
    FIELD_OPTIONS,
)
from hooks.functions.common_functions import message_logging


DOCUMENTATION = """
pytest for validation of group_vars/*/mlag_handover.yml and host_vars/*/*:single_handover data models.
The tests for valid dictionary keys and data types.
"""

REQUIREMENTS = """
"""


def key_checks(filename, handovers, datatype) -> bool:
    """
    Validates the keys for the given datamodel and returns a bool pass/fail
    """
    error = False
    for handover in handovers:
        for handover, values in handover.items():
            if not set(MINIMAL_KEYS[datatype]).issubset(values.keys()):
                message_logging(
                    filename=filename,
                    message_title="KeyError",
                    message=f"Handover: {handover} - Missing keys {list(set(MINIMAL_KEYS[datatype]) - set(values.keys()))}",
                )
                error = True

            for key in values:
                if key not in ALLOWED_KEYS[datatype]:
                    message_logging(
                        filename=filename,
                        message_title="KeyError",
                        message=f"Handover: {handover} - Invalid keys: {list(set(values.keys() - set(ALLOWED_KEYS[datatype])))}",
                    )
                    error = True

    return error


def value_checks(filename, handovers) -> bool:
    """
    Validates the values for each key against FIELD_TYPES
    """
    error = False
    try:
        for handover in handovers:
            for handover, values in handover.items():
                for k, v in values.items():
                    # Check the key.value is equal to FIELD_TYPE[key]
                    if isinstance(v, (str, int)):
                        error = False if type(v) == FIELD_TYPES[k] else True

                    # Treat lists a little differently
                    elif isinstance(v, list):
                        error = False if all(isinstance(x, FIELD_TYPES[k]) for x in v) else True

                    if error:
                        message_logging(
                            filename=filename,
                            message_title="TypeError",
                            message=f"Handover: {handover} - Key '{k}' should be {FIELD_TYPES[k]} or list of {FIELD_TYPES[k]}",
                        )

    except KeyError:
        error = True
        message_logging(
            filename=filename,
            message_title="KeyError",
            message=f"Handover: {handover} - Key '{k} not configured in config/handover.py:FIELD_TYPES'",
        )
        raise KeyError(
            "pre-commit configuration required for new field option, refer ./hooks/config/handover.py:FIELD_TYPES"
        )

    return error


def option_check(filename, handovers) -> bool:
    """
    Validates key values pairs based on options defined in FIELD_OPTIONS
    """
    error = False
    for handover in handovers:
        for handover, values in handover.items():
            for k, v in values.items():
                if k in FIELD_OPTIONS:
                    error = True if v not in FIELD_OPTIONS[k] else False

                    if error:
                        message_logging(
                            filename=filename,
                            message_title="OptionError",
                            message=f"Handover: {handover} - Key '{k}' should be one of {FIELD_OPTIONS[k]}, found '{v}'",
                        )

    return error


def _run_test(filename) -> bool:
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked

    Passes either a playbook or role dir into ansible-lint for processing
    As pre-commit passes a list of files that have changed there is need
    to track what has been parsed already
    """
    error = False  # default setting
    handovers = []  # default setting

    try:

        with open(filename) as f:
            yaml_file = yaml.load(f, Loader=yaml.FullLoader)
            if "mlag_handovers" in yaml_file:
                handovers, datatype = yaml_file["mlag_handovers"], "MLAG"
            elif "single_handovers" in yaml_file:
                handovers, datatype = yaml_file["single_handovers"], "ONEARM"

            if handovers:
                error = []  # rewrite to list
                error.append(key_checks(filename, handovers, datatype))
                error.append(value_checks(filename, handovers))
                error.append(option_check(filename, handovers))
                error = True if any(error) else False

    except Exception as e:
        exc = "{} - {}: {}".format(datetime.now(), type(e).__name__, e)
        print("Something went wrong: {}".format(exc))
        traceback.print_exc()
        error = True
        pass

    return error


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)
    error = False

    for filename in args.filenames:
        error = _run_test(filename) if error is not True else error

    try:
        return error

    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
