# !/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@pandanz)
"""
Loads site handovers from groups_vars and host_vars and verifies
all configured interfaces have monitoring_tags set
"""
import argparse
import sys
import traceback
from datetime import datetime

import yaml

DOCUMENTATION = """
Loads site handovers from groups_vars and host_vars and verifies
all configured interfaces have monitoring_tags set.
"""

RETURNS = """
PASS/FAIL
Lists yaml dictionaries without  missing monitoring_tags set.
"""

monitoring_tag_yaml = "group_vars/monitoring_tags/tags.yml"


def _run_test(filename, ci):
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked
    Comments: Prints results to stdout as part of test run.
    """
    error = False
    try:
        valid_monitoring_tags = []

        with open(filename) as f:
            yamldata = yaml.load(f, Loader=yaml.FullLoader)

        # list of valid monitoring tags
        if yamldata.get("valid_monitoring_tags", []):
            for valid_tags in yamldata.get("valid_monitoring_tags", []):
                valid_monitoring_tags.append(valid_tags["tag"])
        else:
            with open(monitoring_tag_yaml) as t:
                tagdata = yaml.load(t, Loader=yaml.FullLoader)
                for valid_tags in tagdata.get("valid_monitoring_tags", []):
                    valid_monitoring_tags.append(valid_tags["tag"])

        # Check if monitoring tags are set and are valid
        for m_handovers in yamldata.get("mlag_handovers", []):
            for key, val in m_handovers.items():
                if "monitoring_tags" not in val:
                    print(
                        f"{key} is missing monitoring_tags field in file {filename}",
                    )
                else:
                    for tag in val["monitoring_tags"]:
                        if tag not in valid_monitoring_tags:
                            print(
                                f"{tag} in {key} is currently not a supported tag in file {filename}",
                            )
                            error = True
        for s_handovers in yamldata.get("single_handovers", []):
            for key, val in s_handovers.items():
                if "monitoring_tags" not in val:
                    print(
                        f"{key} is missing monitoring_tags field in file {filename}",
                    )
                    error = True
                else:
                    for tag in val["monitoring_tags"]:
                        if tag not in valid_monitoring_tags:
                            print(
                                f"{tag} in {key} is currently not a supported tag in file {filename}",
                            )
                            error = True

    except Exception as e:
        exc = f"{datetime.now()} - {type(e).__name__}: {e}"
        print(f"Something went wrong: {exc}")
        traceback.print_exc()
        error = True
        pass

    return error


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)
    error = False

    for filename in args.filenames:
        error = _run_test(filename, ci=False) if error is not True else error

    try:
        return error
    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
