#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Tests that ansible-inventory can be parsed
"""
import sys
import traceback

from datetime import datetime
from hooks.functions.common_functions import load_ansible_inventory
from hooks.functions.common_functions import message_logging

DOCUMENTATION = """
Tests that ansible-inventory can be parsed
"""

RETURNS = """
PASS/FAIL
Dictionary containing errors.
"""


def _run_test() -> bool:
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked
    Returns: bool
    """
    error = False

    try:
        inventory = load_ansible_inventory("hosts")
        error = False if bool(inventory["_meta"]["hostvars"]) else True
        if error is True:
            message_logging(
                filename="*",
                message_title="Parse failure",
                message="Proposed changes result in ansible-inventory failing to load.",
            )
            message_logging(
                filename="*",
                message_title="Parse failure",
                message="Run `ansible-inventory -i host --list` for details.",
            )

        return error

    except Exception as e:
        exc = "{} - {}: {}".format(datetime.now(), type(e).__name__, e)
        print("Something went wrong: {}".format(exc))
        traceback.print_exc()
        error = True
        pass


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    error = False
    error = _run_test() if error is not True else error

    try:
        return error
    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
