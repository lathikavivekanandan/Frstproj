#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Loads all site handovers and verify vlan with tags exists.
Reports errors for any handovers with orphan tags
"""
import argparse
import sys
import traceback
import yaml

from datetime import datetime
from glob import glob
from hooks.functions.common_functions import get_site_code
from hooks.functions.common_functions import message_logging
from hooks.functions.common_functions import tag_cleanup

DOCUMENTATION = """
Loads all site handovers and verify vlan with tags exists.
Reports errors for any handovers with orphan tags.
"""

RETURNS = """
PASS/FAIL
Dictionary containing errors.
"""

TAGS_TO_SKIP = ["all", "ucs", "evpn"]
CHECKED_FILES = []


def _get_vlan_data(filename) -> dict:
    """
    Retuns the vlan_data for the given site
    Returns a dict
    """
    with open(filename) as f:
        site_vlans = yaml.load(f, Loader=yaml.FullLoader)["site_vlans"]

    return site_vlans


def _run_test(filename) -> bool:
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked
    Returns: bool
    """
    error = False
    try:

        # get the handover data and site code.
        site = get_site_code(filename)
        host_vars_files = glob(
            f"host_vars/vcan-{site}-*.yml",
        )  # load the site single_handovers
        mlag_handovers_files = glob(
            f"group_vars/{site}_sw*_*/mlag_handovers.yml",
        )  # load the site MLAGs

        # generate a unique list of vlan tags
        site_vlans = _get_vlan_data(
            f"group_vars/{site}_vlans/vlans.yml",
        )  # loads the sites vlans model
        vlan_tags = _vlan_tag_list(site_vlans)
        vlan_tags = tag_cleanup(vlan_tags, TAGS_TO_SKIP)

        # generate the handover datasets
        mlag_handovers = _handover_processor(
            mlag_handovers_files,
            handover_type="mlag",
        )
        single_handovers = _handover_processor(
            host_vars_files,
            handover_type="single",
        )

        # process mlag_handovers
        if len(mlag_handovers) > 0:
            error = _tag_processor(
                handovers=mlag_handovers,
                site_vlan_tags=vlan_tags,
            )

        # process single_handovers
        if len(single_handovers) > 0:
            error = _tag_processor(
                handovers=single_handovers,
                site_vlan_tags=vlan_tags,
            )

        error = error if error is not True else error

    except Exception as e:
        exc = "{} - {}: {}".format(datetime.now(), type(e).__name__, e)
        print("Something went wrong: {}".format(exc))
        traceback.print_exc()
        error = True
        pass

    return error


def _vlan_tag_list(vlan_data=None) -> list:
    """
    Checks that tags on vlan exists in site_tags
    params:
        vlan_data: dictionary of single vlan
    Returns: list
    """
    results = []
    for vlan in vlan_data:
        for tag in vlan["tags"]:
            results.append(tag)

    return results


def _tag_processor(handovers=None, site_vlan_tags=None, filename=None):
    """
    Check handovers for corresponding vlan tags
    params:
        handovers: dictionary of handovers
        site_vlan_tags: unique list of vlan tags
    Returns: bool
    Comments: Prints results to stdout as part of test run.
    """
    error = False

    for filename, handover in handovers.items():
        for handover in handover:
            for name, data in handover.items():
                for tag in data["tags"]:
                    if tag not in site_vlan_tags and tag not in TAGS_TO_SKIP:

                        # set the interface variable
                        if "mlag_handovers" in filename:
                            interface = data["members"]
                        else:
                            interface = data["interface"]

                        error = False
                        message_logging(
                            level="WARN",
                            filename=filename,
                            message_title="Orphan Tag Detected",
                            message=f"Tag '{tag}' found on handover not in vlans.yml",
                            data=(filename, interface),
                        )

    return error


def _handover_processor(handover_files, handover_type=None) -> list:
    """
    params:
        handover_files: The list of files passed in from glob
        handover_type: either 'single' or 'mlag'
    Returns: Dict of lists containing handovers
    """
    results = {}
    for handover_file in handover_files:

        if handover_file not in CHECKED_FILES:

            results[handover_file] = []

            with open(handover_file) as f:
                if handover_type == "mlag":
                    handover_data = yaml.load(f, Loader=yaml.FullLoader)["mlag_handovers"]

                elif handover_type == "single":
                    handover_data = yaml.load(f, Loader=yaml.FullLoader)
                    handover_data = handover_data["single_handovers"] if "single_handovers" in handover_data else None

            if handover_data is not None:
                results[handover_file].extend(handover_data)

            CHECKED_FILES.append(handover_file)

    return results


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)
    error = False

    for filename in args.filenames:
        error = _run_test(filename) if error is not True else error

    try:
        return error
    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
