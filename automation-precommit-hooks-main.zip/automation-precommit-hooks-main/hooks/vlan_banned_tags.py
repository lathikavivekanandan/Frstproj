#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Loads site_vlans from groups_vars/*-vlans/vlans.yml
Verifies that tags do not contain banned values.
"""
import argparse
import sys
import traceback
import yaml

from datetime import datetime
from hooks.functions.common_functions import message_logging

DOCUMENTATION = """
Loads site_vlans from groups_vars/*-vlans/vlans.yml
Verifies that tags do not contain banned values.
"""

RETURNS = """
PASS/FAIL
Dictionary containing errors.
"""

BANNED_TAGS = ["none"]


def _run_test(filename):
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked
    Comments: Prints results to stdout as part of test run.
    """
    error = False
    try:
        with open(filename) as f:
            site_vlans = yaml.load(f, Loader=yaml.FullLoader)["site_vlans"]

        # Check for minimal keys
        for vlan in site_vlans:
            for tag in vlan["tags"]:
                if tag in BANNED_TAGS:
                    # Return list position of banned tag
                    position = vlan["tags"].index(tag)
                    tag = vlan["tags"][position]
                    message_logging(
                        filename=filename,
                        message_title="Banned tag detected",
                        message=f"Vlan: {vlan['vlan_id']} - Has banned tag '{tag}''",
                    )
                    error = True

    except Exception as e:
        exc = "{} - {}: {}".format(datetime.now(), type(e).__name__, e)
        print("Something went wrong: {}".format(exc))
        traceback.print_exc()
        error = True
        pass

    return error


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)
    error = False

    for filename in args.filenames:
        error = _run_test(filename) if error is not True else error

    try:
        return error
    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
