#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Loads site_vlans from groups_vars/*_vlans/vlams.yml and verifies
all configured tags exist as tags on defined handovers
"""
import argparse
import sys
import yaml
import traceback

from datetime import datetime
from glob import glob
from hooks.functions.common_functions import get_site_code
from hooks.functions.common_functions import message_logging
from hooks.functions.common_functions import tag_cleanup

DOCUMENTATION = """
Loads site_vlans from groups_vars/*_vlans/vlams.yml and verifies
all configured tags exist as tags on defined handovers.
"""

RETURNS = """
PASS/FAIL
Dictionary containing errors.
"""

TAGS_TO_SKIP = ["badname", "all", "vcr", "ucs", "empty", "", "none"]
SITES_TO_SKIP = ["a04", "a03", "d00", "d02"]


def skip_site_check(filename: str, sites: list) -> bool:
    """
    Tests is the submitted filename contains
    a sitename that should be skipped.
    params:
      filename:
        type: string
        contents: path to filename
      sites:
        type: list
        contents: all sites to skip
    returns: bool
    True = skip site
    False = don't skip site
    """
    for site in SITES_TO_SKIP:
        if site not in filename:
            result = False
        elif site in filename:
            result = True
            break
    return result


def _run_test(filename) -> bool:
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked
    Returns: bool
    """
    error = False
    skip = False
    skip = skip_site_check(filename, SITES_TO_SKIP)
    try:
        if skip is False:
            with open(filename) as f:
                site_vlans = yaml.load(f, Loader=yaml.FullLoader)["site_vlans"]

            site = get_site_code(filename)
            host_vars_files = glob(
                f"host_vars/vcan-{site}-*.yml",
            )  # load the site single_handovers
            mlag_handovers_files = glob(
                f"group_vars/{site}_sw*_*/mlag_handovers.yml",
            )  # load the site MLAGs

            # Get list of unqiue tags for site
            # unique_tags is the set with unique list after this
            try:
                mlag_tags = _handover_processor(
                    mlag_handovers_files,
                    handover_type="mlag",
                )
                single_handover_tags = _handover_processor(
                    host_vars_files,
                    handover_type="single",
                )
                site_tags = mlag_tags + single_handover_tags  # merge the two tag lists
                unique_tags = tag_cleanup(
                    site_tags,
                    TAGS_TO_SKIP,
                )  # make the list contain only unique, tracked tags
            except (UnboundLocalError, Exception):
                message_logging(
                    filename=filename,
                    message_title="Unmanaged Site",
                    message=f"{site} - Handovers are managed manually",
                )
                pass

            # now check every vlan for tag existence
            if len(site_tags) > 0:  # Some sites are not yet automated and have no host_vars
                for vlan in site_vlans:
                    results = _check_vlan_tags(vlan, filename, unique_tags)
                    error = results if error is not True else error

    except Exception as e:
        exc = "{} - {}: {}".format(datetime.now(), type(e).__name__, e)
        print("Something went wrong: {}".format(exc))
        traceback.print_exc()
        error = True
        pass

    return error


def _check_vlan_tags(vlan_data=None, filename=None, site_tags=None) -> bool:
    """
    Checks that tags on vlan exists in site_tags
    params:
        vlan_data: dictionary of single vlan
        filename: path to file being tested
        site_tags: list of tags
    Returns: bool
    Comments: Prints results to stdout as part of test run.
    """
    error = False
    if "tags" in vlan_data:
        for tag in vlan_data["tags"]:
            if tag not in site_tags and tag not in TAGS_TO_SKIP:
                message_logging(
                    filename=filename,
                    message_title="Tag Error",
                    message=f"VLAN: {vlan_data['vlan_id']} - Tag: '{tag}' does not exist",
                )
                error = True

    else:
        print(f"File: {filename} - VLAN: {vlan_data['vlan_id']} has no tags")
        error = True

    return error


def _get_handover_tags(handover_data) -> list:
    """
    params:
        handover_data: handover file data
    Returns: list of valid tags to use on vlans in vlans.yml
    """

    # get the full tags list from the handover
    result = handover_data["tags"] if "tags" in handover_data else []

    # check for native vlan
    # append if not already in the tag list
    result.append(handover_data["native"]) if "native" in handover_data and handover_data[
        "native"
    ] not in result else None

    return result


def _handover_processor(handover_files, handover_type=None) -> list:
    """
    params:
        handover_files: The list of files passed in from glob
        handover_type: either 'single' or 'mlag'
    extends: SITE_TAGS to unqiue list of tags found within the sites handovers
    Returns: List of discovered tags
    """
    results = []
    for handover_file in handover_files:

        with open(handover_file) as f:
            if handover_type == "mlag":
                handovers = yaml.load(f, Loader=yaml.FullLoader)["mlag_handovers"]
            elif handover_type == "single":
                handovers = yaml.load(f, Loader=yaml.FullLoader)
                handovers = handovers["single_handovers"] if "single_handovers" in handovers else None

        if handovers is not None:
            for handover in handovers:
                for data in handover.values():
                    results.extend(_get_handover_tags(handover_data=data))

    return results


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", nargs="*", help="Filenames to check.")
    args = parser.parse_args(argv)
    error = False

    for filename in args.filenames:
        error = _run_test(filename) if error is not True else error

    try:
        return error
    except Exception:
        return True


if __name__ == "__main__":
    sys.exit(main())
