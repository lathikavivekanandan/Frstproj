#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Loads site_vlans from groups_vars/*_vlans/vlams.yml and provides
a warning if a change will remove this vlan from any interfaces
"""
import sys
import traceback
import yaml
import json

from datetime import datetime
from hooks.functions.common_functions import get_site_code
from hooks.functions.common_functions import load_ansible_inventory
from hooks.functions.common_functions import get_changed_files_from_master
from hooks.functions.common_functions import get_master_file


DOCUMENTATION = """
Compares branch vlans.yml to master, determines if VLANs will be removed from ports
and provides a feedback to the developer.

Excludes: Any interfaces that are also being decomissioned or tags removed from those ports
"""

RETURNS = """
INFORMATION ONLY
TEST ALWAYS PASSES
"""


def get_switch_ports(inventory: dict, site: str) -> list:
    """
    param:
      inventory: ansible-inventory from def(load_ansible_inventory)
      site: sitecode
    Returns: list of dicts
      hostname { handover_data }
    [
        {
            "hostname": "vcan-a03-am2140-lyc01b.vcan.local",
            "interfaces": [
                {
                    "vcan-a03-am21-syn01-infra": {
                        "client_id": 0,
                        "description": "vcan-a03-am21-syn01a/b IaaS Infrastructure VLANs",
                        "members": ["Ethernet1", "Ethernet2", "Ethernet5", "Ethernet6"],
                        "portchannel": 1,
                        "speed": "25gfull",
                        "tags": ["esxi_infra"],
                        "type": "infrastructure",
                    }
                },
                {
                    "vcan-a03-am21-syn01-workload": {
                        "client_id": 0,
                        "description": "vcan-a03-am21-syn01a/b IaaS Workload VLANs",
                        "members": ["Ethernet3", "Ethernet4", "Ethernet7", "Ethernet8"],
                        "portchannel": 5,
                        "speed": "25gfull",
                        "tags": ["vcr", "synergy"],
                        "type": "infrastructure",
                    }
                },
                {
                    "a03-nexus5k": {
                        "client_id": 0,
                        "description": "ccl-a03-az0326/7-n5ka/b Po99",
                        "members": ["Ethernet9", "Ethernet10"],
                        "portchannel": 9,
                        "tags": ["all"],
                        "type": "infrastructure",
                    }
                },
                {
                    "vbridge-hwr-handover": {
                        "client_id": 4801,
                        "description": "vBridge L2 handover for HW Richardson migration",
                        "members": ["Ethernet12"],message_logging
                        "interface": "Ethernet11",
                        "native": "vcan_mgmt",
                        "speed": "1000full",
                        "tags": ["vcan_mgmt"],
                        "type": "infrastructure",
                    }
                },
            ],
        }
    ]
    """
    results = []
    for hostname, data in inventory["_meta"]["hostvars"].items():
        interfaces = []
        if site in hostname and ("mlag_handovers" in data or "single_handovers" in data):
            interfaces.extend(data["mlag_handovers"]) if "mlag_handovers" in data else None
            interfaces.extend(data["single_handovers"]) if "single_handovers" in data else None
            results.append(dict(hostname=hostname, interfaces=interfaces))
    return results


def stage1_datamodel(branch: str, master: str) -> list:
    """
    Returns the difference between two lists of dictionaries containing vlans
    params:
      branch: The parse site_vlans file from the feature branch.
      master: The current master version of site_vlans
    returns: list of dicts of differences, key idxing as
    {
        "master":{
            "CDHB_2_SharedHosts2":{
                "vlan_id":2,
                "tags":[
                    "badname",
                    "cdhb_sw",
                    "vcr"
                ],
                "client_id":1227
            },
            "CDHB_3_PSEHosts":{
                "vlan_id":3,
                "tags":[
                    "badname",
                    "cdhb_sw",
                    "vcr"
                ],
                "client_id":1227
            },
            "CDHB_4_PathHosts":{
                "vlan_id":4,
                "tags":[
                    "badname",
                    "cdhb_sw",
                    "vcr"
                ],
                "client_id":1227
            }
        },
        "branch":{
            "CDHB_3_PSEHosts":{
                "vlan_id":3,
                "tags":[
                    "badname",
                    "vcr"
                ],
                "client_id":1227
            }
        }
    }
     Sample Data:
        diff --git a/group_vars/c00_vlans/vlans.yml b/group_vars/c00_vlans/vlans.yml
        index bb4cab50..c7d16b94 100644
        --- a/group_vars/c00_vlans/vlans.yml
        +++ b/group_vars/c00_vlans/vlans.yml
        @@ -1,7 +1,7 @@
        ---
        site_vlans:
        -  - { vlan_name: CDHB_3_PSEHosts, vlan_id: 3, tags: ['badname','cdhb_sw','vcr'], client_id: 1227 }
        +  - { vlan_name: CDHB_3_PSEHosts, vlan_id: 3, tags: ['badname','vcr'], client_id: 1227 }

        -  - { vlan_name: ATS_Solarix_SBC, vlan_id: 12, tags: ['vcr','ats_solarix'], client_id: 5873 }
        +  - { vlan_name: ATS_Solarix_SBC, vlan_id: 12, tags: ['vcr'], client_id: 5873 }

        -  - { vlan_name: TEL_INET_PE01, vlan_id: 18, tags: ['pe01','teltrac_sw'], client_id: 4526 }
        +  - { vlan_name: TEL_INET_PE01, vlan_id: 18, tags: ['pe01'], client_id: 4526 }
    """

    def data_model(data: list) -> dict:
        """
        Convert the data model from a dict containing lists of dicts to pure dictionary
        params: list of vlans
        returns: dict
        """
        results = dict()
        for x in data:
            results[x.get("vlan_name")] = dict(
                vlan_id=x.get("vlan_id"), tags=x.get("tags"), client_id=x.get("client_id")
            )
        return results

    a_minus_b = [item for item in branch if item not in master]
    b_minus_a = [item for item in master if item not in branch]

    # convert lists of dicts to dict of dicts
    master_vlans = data_model(b_minus_a)
    branch_vlans = data_model(a_minus_b)

    return dict(master=master_vlans, branch=branch_vlans)


def stage2_datamodel(diff: dict) -> list:
    """
    params:
       diff: dict of branch vlan information as returned from stage1_datamodel()
    Returns: List of dicts
    [
        {
            "vlan_name":"CDHB_2_SharedHosts2",
            "state":"deleted",
            "vlan_id":2,
            "tags":[
                "badname",
                "cdhb_sw",
                "vcr"
            ],
            "client_id":1227
        },
        {
            "vlan_name":"CDHB_3_PSEHosts",
            "state":"modified",
            "vlan_id":3,
            "tags":[
                "badname",
                "cdhb_sw",
                "vcr"
            ],
            "client_id":1227,
            "feat_branch_removed_tags":[
                "cdhb_sw"
            ]
        },
        {
            "vlan_name":"CDHB_4_PathHosts",
            "state":"deleted",
            "vlan_id":4,
            "tags":[
                "badname",
                "cdhb_sw",
                "vcr"
            ],
            "client_id":1227
        },
        {
            "vlan_name":"DONALD_TEST",
            "state":"new",
            "vlan_id":4000,
            "tags":[
                "fw",
                "cpe"
            ],
            "client_id":0
        }
    ]
    """
    results = []
    # compare master to branch
    for vlan_name, vlan_data in diff.get("master").items():
        # search for and record vlans with modified tags
        if vlan_name in diff.get("branch"):
            branch_vlan = diff["branch"].get(vlan_name)
            results.append(
                dict(
                    vlan_name=vlan_name,
                    state="modified",
                    **vlan_data,
                    feat_branch_removed_tags=list(set(vlan_data["tags"]) - set(branch_vlan["tags"])),
                )
            )
        # search for and record deleted vlans
        elif vlan_name not in diff.get("branch"):
            results.append(
                dict(
                    vlan_name=vlan_name,
                    state="deleted",
                    **vlan_data,
                )
            )

    # compare branch to master
    # search for and record new vlans
    for vlan_name, vlan_data in diff.get("branch").items():
        if vlan_name not in diff.get("master"):
            results.append(
                dict(
                    vlan_name=vlan_name,
                    state="new",
                    **vlan_data,
                )
            )
    return results


def stage3_datamodel(switch_ports: list, diff: list) -> None:
    """
    params:
        switch_ports: list of dicts from get_switch_ports()
        diff: lit of dicts from stage2_datamodel()
    returns: modified diff dict

    Method will alter diff on the fly
    Sample:
    [
        {
            "vlan_name": "CDHB_3_PSEHosts",
            "vlan_id": 3,
            "state": 'modified,
            "tags": ["badname", "cdhb_sw", "vcr"],
            "client_id": 1227,
            "feat_branch_removed_tags": ["cdhb_sw"],
            "cdhb_sw": {
                "impacted_interfaces": [
                    {
                        "hostname": "vcan-c00-e0837-lyc01a.vcan.local",
                        "handover": "cdhb_4500x",
                        "interfaces": ["Ethernet48"],
                    },
                    {
                        "hostname": "vcan-c00-e0937-lyc01b.vcan.local",
                        "handover": "cdhb_4500x",
                        "interfaces": ["Ethernet48"],
                    },
                ]
            },
        },
        {
            "vlan_name": "ATS_Solarix_SBC",
            "vlan_id": 12,
            "state": 'modified,
            "tags": ["vcr", "ats_solarix"],
            "client_id": 5873,
            "feat_branch_removed_tags": ["ats_solarix"],
            "ats_solarix": {
                "impacted_interfaces": [
                    {
                        "hostname": "vcan-c00-j1624-ltr01b.vcan.local",
                        "handover": "ats_solarix",
                        "interfaces": "Ethernet3",
                    }
                ]
            },
        },
        {
            "vlan_name": "TEL_INET_PE01",
            "vlan_id": 18,
            "state": 'modified,
            "tags": ["pe01", "teltrac_sw"],
            "client_id": 4526,
            "feat_branch_removed_tags": ["teltrac_sw"],
            "teltrac_sw": {
                "impacted_interfaces": [
                    {
                        "hostname": "vcan-c00-j0124-ltr01a.vcan.local",
                        "handover": "TelTrac_SW",
                        "interfaces": ["Ethernet36"],
                    },
                    {
                        "hostname": "vcan-c00-j1624-ltr01b.vcan.local",
                        "handover": "TelTrac_SW",
                        "interfaces": ["Ethernet36"],
                    },
                ]
            },
        },
        {
            "vlan_name": "HTG_WAN_SEC",
            "vlan_id": 94,
            "state": 'modified,
            "tags": ["fw", "cpe"],
            "client_id": 2923,
            "feat_branch_removed_tags": ["cpe", "fw"],
            "cpe": {
                "impacted_interfaces": [
                    {
                        "hostname": "vcan-c00-a0806-lyc01a.vcan.local",
                        "handover": "chc01-cpe01",
                        "interfaces": ["Ethernet8"],
                    },
                    {
                        "hostname": "vcan-c00-a0806-lyc01a.vcan.local",
                        "handover": "chc01-cpe02",
                        "interfaces": ["Ethernet9"],
                    },
                    {
                        "hostname": "vcan-c00-a0906-lyc01b.vcan.local",
                        "handover": "chc01-cpe01",
                        "interfaces": ["Ethernet8"],
                    },
                    {
                        "hostname": "vcan-c00-a0906-lyc01b.vcan.local",
                        "handover": "chc01-cpe02",
                        "interfaces": ["Ethernet9"],
                    },
                ]
            },
            "fw": {
                "impacted_interfaces": [
                    {
                        "hostname": "vcan-c00-a0806-lyc01a.vcan.local",
                        "handover": "vcan-c00-fw04a",
                        "interfaces": ["Ethernet10"],
                    },
                    {
                        "hostname": "vcan-c00-a0806-lyc01a.vcan.local",
                        "handover": "vcan-c00-fw04b",
                        "interfaces": ["Ethernet11"],
                    },
                    {
                        "hostname": "vcan-c00-a0906-lyc01b.vcan.local",
                        "handover": "vcan-c00-fw04a",
                        "interfaces": ["Ethernet10"],
                    },
                    {
                        "hostname": "vcan-c00-a0906-lyc01b.vcan.local",
                        "handover": "vcan-c00-fw04b",
                        "interfaces": ["Ethernet11"],
                    },
                    {
                        "hostname": "vcan-c00-e0837-lyc01a.vcan.local",
                        "handover": "vcan-c00-fw01a",
                        "interfaces": ["Ethernet9"],
                    },
                    {
                        "hostname": "vcan-c00-e0837-lyc01a.vcan.local",
                        "handover": "vcan-c00-fw01b",
                        "interfaces": ["Ethernet10"],
                    },
                    {
                        "hostname": "vcan-c00-e0837-lyc01a.vcan.local",
                        "handover": "vcan-c00-fw05a",
                        "interfaces": ["Ethernet13"],
                    },
                    {
                        "hostname": "vcan-c00-e0837-lyc01a.vcan.local",
                        "handover": "vcan-c00-fw05b",
                        "interfaces": ["Ethernet14"],
                    },
                    {
                        "hostname": "vcan-c00-e0937-lyc01b.vcan.local",
                        "handover": "vcan-c00-fw01a",
                        "interfaces": ["Ethernet9"],
                    },
                    {
                        "hostname": "vcan-c00-e0937-lyc01b.vcan.local",
                        "handover": "vcan-c00-fw01b",
                        "interfaces": ["Ethernet10"],
                    },
                    {
                        "hostname": "vcan-c00-e0937-lyc01b.vcan.local",
                        "handover": "vcan-c00-fw05a",
                        "interfaces": ["Ethernet13"],
                    },
                    {
                        "hostname": "vcan-c00-e0937-lyc01b.vcan.local",
                        "handover": "vcan-c00-fw05b",
                        "interfaces": ["Ethernet14"],
                    },
                ]
            },
        },
    ]
    """
    for idx, vlan in enumerate(diff):
        if vlan.get("feat_branch_removed_tags"):
            for tag in vlan.get("feat_branch_removed_tags"):
                diff[idx][tag] = dict(impacted_interfaces=list())
                for switch in switch_ports:
                    for ints in switch["interfaces"]:
                        for handover, data in ints.items():
                            if tag in data["tags"]:
                                diff[idx][tag]["impacted_interfaces"].append(
                                    dict(
                                        hostname=switch["hostname"],
                                        handover=handover,
                                        interfaces=data["members"] if "members" in data else data["interface"],
                                    )
                                )
        else:
            for tag in vlan.get("tags"):
                diff[idx][tag] = dict(impacted_interfaces=list())
                for switch in switch_ports:
                    for ints in switch["interfaces"]:
                        for handover, data in ints.items():
                            if tag in data["tags"]:  # or "all" in data["tags"]:
                                diff[idx][tag]["impacted_interfaces"].append(
                                    dict(
                                        hostname=switch["hostname"],
                                        handover=handover,
                                        interfaces=data["members"] if "members" in data else data["interface"],
                                    )
                                )
    return diff


def log_to_stdout(diff: dict) -> None:
    """
    params:
        diff: dict from stage3_datamodel()
    Return None:

    Prints warnings to user.
    Sample Output:

    DELETED VLAN: CDHB_2_SharedHosts2, with id: 2, and Removed Tag: `cdhb_sw`, will be deprovisioned from 2 interfaces
    [
        {
            "hostname": "vcan-c00-e0837-lyc01a.vcan.local",
            "handover": "cdhb_4500x",
            "interfaces": [
                "Ethernet48"
            ]
        },
        {
            "hostname": "vcan-c00-e0937-lyc01b.vcan.local",
            "handover": "cdhb_4500x",
            "interfaces": [
                "Ethernet48"
            ]
        }
    ]
    DELETED VLAN: CDHB_4_PathHosts, with id: 4, and Removed Tag: `cdhb_sw`, will be deprovisioned from 2 interfaces
    [
        {
            "hostname": "vcan-c00-e0837-lyc01a.vcan.local",
            "handover": "cdhb_4500x",
            "interfaces": [
                "Ethernet48"
            ]
        },
        {
            "hostname": "vcan-c00-e0937-lyc01b.vcan.local",
            "handover": "cdhb_4500x",
            "interfaces": [
                "Ethernet48"
            ]
        }
    ]
    NEW VLAN: DONALD_TEST, with id: 4000, and Tag: `cpe`, will be added to 4 interfaces
    [
        {
            "hostname": "vcan-c00-a0806-lyc01a.vcan.local",
            "handover": "chc01-cpe01",
            "interfaces": [
                "Ethernet8"
            ]
        },
        {
            "hostname": "vcan-c00-a0806-lyc01a.vcan.local",
            "handover": "chc01-cpe02",
            "interfaces": [
                "Ethernet9"
            ]
        },
        {
            "hostname": "vcan-c00-a0906-lyc01b.vcan.local",
            "handover": "chc01-cpe01",
            "interfaces": [
                "Ethernet8"
            ]
        },
        {
            "hostname": "vcan-c00-a0906-lyc01b.vcan.local",
            "handover": "chc01-cpe02",
            "interfaces": [
                "Ethernet9"
            ]
        }
    ]
    """

    def out(tags_key: str, payload: dict) -> None:
        """
        Does the printing to stdou
        params:
          tags_key: The key to iterate over
          payload: The message variables to use
        """
        for tag in vlan.get(tags_key):
            if tag in vlan:
                for tag_impact, impact_data in vlan[tag].items():
                    if len(impact_data) > 0:
                        print(
                            f"{payload['change_type']} VLAN: '{payload['vlan_name']}', with id: {payload['vlan_id']}, and Tag: '{tag}', will be {payload['action']} {len(impact_data)} interfaces"
                        )
                        print(json.dumps(impact_data, indent=4))
        return None

    for vlan in diff:
        if vlan.get("state") == "modified" and vlan.get("feat_branch_removed_tags"):
            payload = dict(
                change_type="MODIFIED", action="removed from", vlan_name=vlan["vlan_name"], vlan_id=vlan["vlan_id"]
            )
            out(tags_key="feat_branch_removed_tags", payload=payload)

        elif vlan.get("state") == "deleted":
            payload = dict(
                change_type="DELETED", action="removed from", vlan_name=vlan["vlan_name"], vlan_id=vlan["vlan_id"]
            )
            out(tags_key="tags", payload=payload)

        elif vlan.get("state") == "new":
            payload = dict(change_type="NEW", action="added to", vlan_name=vlan["vlan_name"], vlan_id=vlan["vlan_id"])
            out(tags_key="tags", payload=payload)
    return None


def _run_test() -> bool:
    """
    Inital entrypoint from __main__:
    params:
        filename: path to file that is checked
    Returns: bool
    """
    error = False
    try:
        changed_vlan_files = [x for x in get_changed_files_from_master() if "vlans.yml" in x or "vlans.yaml" in x]
        if changed_vlan_files:
            for filename in changed_vlan_files:
                # obtains the sitecode, load inventory and gather switch interfaces
                sitecode = get_site_code(filename)
                inventory = load_ansible_inventory("hosts")
                switch_ports = get_switch_ports(inventory, sitecode)

                # load the current branch version of this changed file
                with open(filename) as f:
                    current_branch_copy = yaml.load(f, Loader=yaml.FullLoader)["site_vlans"]
                master_copy = yaml.load(get_master_file(filename), Loader=yaml.FullLoader)["site_vlans"]
                # diff the files so we can play with the tags on each vlan
                diff = stage1_datamodel(current_branch_copy, master_copy)
                diff = stage2_datamodel(diff)

                impact = stage3_datamodel(switch_ports, diff)
                log_to_stdout(impact)

    except Exception as e:
        exc = "{} - {}: {}".format(datetime.now(), type(e).__name__, e)
        print("Something went wrong: {}".format(exc))
        traceback.print_exc()
        error = True
        pass

    return error


def main(argv=None) -> bool:
    """
    Returns: bool as sys.exit code.  True = 1, False = 0.  Zero is good.
    """
    error = _run_test()
    return error


if __name__ == "__main__":
    sys.exit(main())
