"""
Sets up pre-commit
"""
from datetime import datetime
from setuptools import setup, find_packages

PACKAGES = find_packages(exclude=["test*", "tests*", "testing*"])

PROJECT_NAME = "ccl_pre_commit_hooks"
PROJECT_PACKAGE_NAME = "ccl_pre_commit_hooks"
PROJECT_LICENSE = "MIT"
PROJECT_AUTHOR = "@johnsondnz"
PROJECT_COPYRIGHT = f"2018-{datetime.now().year}"
PROJECT_URL = "https://gitlab.com/ComputerConceptsLimited/pre-commit-hooks.git"
PROJECT_EMAIL = "donald.johnson@concepts.co.nz"
PROJECT_VERSION = "1.2.19"

REQUIRES = [
    "flake8==3.9.2",
    "six",
    "typing",
    "PyYAML>=5.1.2",
    "netaddr",
    "ansible",
    "ansible-lint",
    "jinja2",
    "logzero",
    "black==21.9b0",
    "interrogate==1.5.0",
    "GitPython==3.1.24",
]

setup(
    name=PROJECT_PACKAGE_NAME,
    version=PROJECT_VERSION,
    url=PROJECT_URL,
    author=PROJECT_AUTHOR,
    author_email=PROJECT_EMAIL,
    packages=PACKAGES,
    include_package_data=True,
    zip_safe=False,
    install_requires=REQUIRES,
    python_requires=">=3.5",
    entry_points={
        "console_scripts": [
            "vlan-duplicates = hooks.vlan_duplicates:main",
            "vlan-keys = hooks.vlan_keys:main",
            "vlan-tags-exist = hooks.vlan_tags_exist:main",
            "vlan-banned-tags = hooks.vlan_banned_tags:main",
            "fmg-client-variables = hooks.fmg_client_variables:main",
            "ansible-lint = hooks.ansible_lint:main",
            "jinja2-lint = hooks.jinja2_lint:main",
            "orphan-handover-tags = hooks.orphan_handover_tags:main",
            "duplicate-interfaces = hooks.duplicate_interfaces:main",
            "duplicate-mlags = hooks.duplicate_mlag:main",
            "inventory = hooks.inventory:main",
            "handover-client-id = hooks.handover_client_id:main",
            "check-ucsc-lookup = hooks.check_ucsc_lookup:main",
            "coding-standards = hooks.coding_standards:main",
            "container-setup = hooks.container_setup:main",
            "vlan-warning = hooks.vlan_warning:main",
            "handover-datamodel = hooks.handover_datamodel:main",
        ]
    },
)
