#!/bin/bash
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)

MODULE=`pip3 list | grep ccl-pre-commit-hooks | awk '{print $1}'`
VERSION=`pip3 list | grep ccl-pre-commit-hooks | awk '{print $2}'`
RETURN=0

echo "==> Testing ccl-pre-commit-hooks is install via pip3"
if [ "$MODULE" = "ccl-pre-commit-hooks" ]; then
    echo "==> ccl-pre-commit-hooks is installed with version $VERSION, exiting..."
    exit 0
else
    echo "==> ccl-pre-commit-hooks is not installed, please install and retry, exiting..."
    exit 1
fi

exit 0
