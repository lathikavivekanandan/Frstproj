#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""ß
Tests hooks.functions.common_functions.get_site_code
"""
from hooks.functions.common_functions import get_site_code


FILENAMES = [
    dict(expected="c00", test_string="group_vars/c00_vlans/vlans.yml"),
    dict(expected="c00", test_string="host_vars/vcan-c00-arista-switch-01"),
    dict(expected="a03", test_string="host_vars/vcan-a03-arista-switch-01"),
]


def test_code_return() -> bool:
    """
    Tests that the get_site_code returns String and site_code
    """
    for f in FILENAMES:
        assert get_site_code(f["test_string"]) == str(f["expected"])
