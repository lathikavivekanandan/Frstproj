#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Tests hooks.functions.common_functions.string_length
"""
from hooks.functions.common_functions import string_length


def test_string_true() -> bool:
    """
    Tests that the string_length returns a value of True
    """
    assert string_length("String", 20)


def test_string_false() -> bool:
    """
    Tests that the string_length returns a value of False
    """
    assert string_length("String", 1) is False
