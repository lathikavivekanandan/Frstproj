#!/usr/bin/env python3
# maintainer (@johnsondnz)
"""
Tests hooks.functions.common_functions.tag_cleanup
"""
from hooks.functions.common_functions import tag_cleanup


def test_tag_cleanup() -> bool:
    """
    Tests that the function returns a unique list
    """
    non_unique = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    unique = tag_cleanup(non_unique)
    assert len(set(non_unique)) != len(unique)


def test_tag_cleanup_with_skip() -> bool:
    """
    Tests that the function returns a unique list
    """
    skip = [1, 2]
    non_unique = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    unique = tag_cleanup(non_unique, skip)
    assert len(set(non_unique)) != len(unique)
