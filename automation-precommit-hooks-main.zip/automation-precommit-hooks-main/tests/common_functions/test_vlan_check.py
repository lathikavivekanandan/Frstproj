#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Tests hooks.functions.common_functions.vlan_check
"""
from hooks.functions.common_functions import vlan_check, VLAN_MIN, VLAN_MAX


VLANS = range(4094)


def test_vlan_check() -> bool:
    """
    Tests the vlan_ids fall within the approve min/max range of 2-4094
    """
    for vlan_id in range(VLAN_MIN, VLAN_MAX, 1):
        assert vlan_check(vlan_id) is True if vlan_id >= VLAN_MIN and vlan_id <= VLAN_MAX else False
