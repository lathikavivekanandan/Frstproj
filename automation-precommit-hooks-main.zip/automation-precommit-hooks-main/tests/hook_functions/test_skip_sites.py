#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# maintainer (@johnsondnz)
"""
Tests hooks.vlan_tags_exist
"""
from hooks.vlan_tags_exist import skip_site_check


SITES_TO_SKIP = ["a04"]
FILENAMES = ["c00-vlans/vlans.yml", "a04-vlans/vlans.yml"]


def test_is_false() -> bool:
    """
    Tests that the skip_site_check returns False
    """
    assert skip_site_check(FILENAMES[0], SITES_TO_SKIP) is False


def test_is_true() -> bool:
    """
    Tests that the skip_site_check returns True
    """
    assert skip_site_check(FILENAMES[1], SITES_TO_SKIP) is True
