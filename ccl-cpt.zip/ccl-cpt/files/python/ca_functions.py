def decrypt(enc_string: str, key: str, iv: str):
    import base64
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    enc_string_base64 = base64.b64decode(enc_string)
    key_base64 = base64.b64decode(key)
    iv_base64 = base64.b64decode(iv)
    cipher = AES.new(key_base64,AES.MODE_CBC,iv_base64)
    plainText = cipher.decrypt(enc_string_base64)
    #AES.block_size = 16, so schema is utf-16
    result = unpad(plainText, AES.block_size).decode('utf-16') #unpad will remove the excess text, decode utf-16 will decode to utf-16 schema
    return result

def get_tss_token(username: str, password: str):
    import sys
    from delinea.secrets.server import PasswordGrantAuthorizer, SecretServer, SecretServerError
    tss_url = "https://creds.pan.net.nz/SecretServer"
    authorizer = PasswordGrantAuthorizer(tss_url,username,password)
    try:
        tss_headers = SecretServer(tss_url, authorizer).headers()
    except SecretServerError as e:
        sys.exit("Error retrieving token from TSS: " + str(e.message))
    except:
        sys.exit("Unknown error retrieving token from TSS")
    tss_token = tss_headers['Authorization'][7:]
    return tss_token

def get_tss_secret(secret_id: int):
    import sys
    from os import getenv
    from delinea.secrets.server import AccessTokenAuthorizer, SecretServer, SecretServerError
    tss_url = "https://creds.pan.net.nz/SecretServer"
    token = getenv('TSS_TOKEN', default=None)
    if token is None or token == '':
        sys.exit("Environment variable TSS_TOKEN not defined")
    authorizer = AccessTokenAuthorizer(token)
    try:
        secret_server = SecretServer(tss_url, authorizer)
        secret = secret_server.get_secret(secret_id)
    except SecretServerError as e:
        sys.exit("Error retrieving secret from TSS: " + str(e.message))
    except:
        sys.exit("Unknown error retrieving secret from TSS")
    secret_dict = {"secretTemplateId" : secret["secretTemplateId"]}
    for field in secret["items"]:
        secret_dict[field["slug"]] = field["itemValue"]
    return secret_dict

def which_os(os_name: str):
    windows = ['Windows', 'Microsoft']
    linux = ['Ubuntu', 'Debian', 'Arch', 'Linux', 'CentOS', 'Rocky', 'Alma', 'RHEL', 'RedHat','Red-Hat','Red Hat']
    for string in windows:
        if string in os_name:
            return 'windows'
    for string in linux:
        if string in os_name:
            return 'linux'
    return 'other'

def load_job_data(data_string: str):
    import ast
    data_string = data_string.replace("null", "''")
    data_dict = ast.literal_eval(data_string)
    return data_dict

def clean_string(data_string: str):
    import re
    data_string = data_string.lower() # Make lower case
    data_string = data_string.strip() # Remove leading or trailing whitespace
    data_string = re.sub(r'\s+', ' ', data_string) # Reduce multiple white spaces to just one
    data_string = re.sub(r'-+', '-', data_string) # Reduce multiple hyphens to just one
    data_string = re.sub(r'\.+', '.', data_string) # Reduce multiple periods to just one
    data_string = re.sub(r'[\s\-\.]', '_', data_string) # Replace spaces, hyphens and periods with underscores
    data_string = re.sub(r'_+', '_', data_string) # Reduce multiple underscores to just one
    data_string = re.sub(r'[^a-z0-9_]', '', data_string) # Remove all other illegal characters
    return data_string