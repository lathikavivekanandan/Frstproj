#!/usr/bin/env python3
#-------------------------
# Import required modules.
#-------------------------

import os
import json
import re
import sys
import argparse
# from ansible_vault import Vault
# from ca_functions import get_tss_secret, load_job_data, which_os, clean_string
# from ca_functions import load_job_data, which_os, clean_string
import ca_functions

#----------------
# Argparse setup.
#----------------

parser = argparse.ArgumentParser()
parser.add_argument("-d", "--data", dest="data", required=True, type=str, help="Job Data string in JSON.", nargs=1, metavar="DATA")
parser.add_argument("-e", "--env", dest="ccl_environment", required=True, type=str, help="CCL environment of operation.", nargs=1, metavar="CCL_ENVIRONMENT")
args = parser.parse_args()

#-----------------------
# Parse argument values.
#-----------------------

data_string = str(args.data[0])
ccl_environment = str(args.ccl_environment[0])

#-------------------------
# Define static variables.
#-------------------------

inventory_dir = "inventory"
ssh_dir = ".ssh"
ssh_private_key_file = 'id_rsa'
ssh_public_key_file = 'id_rsa.pub'
tss_ssh_secret_template_id = 7061
inventory_file = 'inventory.yaml'
# vault_file = 'vault.yaml'
ssh_port = 22
winrm_port = 5985
winrm_scheme = 'http'
winrm_transport = 'ntlm'
token = os.getenv('TSS_TOKEN', default=None)
customer_ref = os.getenv('CUSTOMER_REF', default=999999)
tss_url = "https://creds.pan.net.nz/SecretServer"

#-----------------------------
# Define enironment variables.
#-----------------------------

# data_string = os.environ['JOB_DATA']
# vault_password = os.environ['ANSIBLE_VAULT_PASSWORD']
# ccl_environment = os.environ['CCL_ENVIRONMENT'].lower()

# --------------
# Begin script.
# --------------

data_dict = ca_functions.load_job_data(data_string)

# for item_check in ['IpAddress','FQDN','MachineName','OperatingSystem','SecretNumber','CoreMachineId']:
for item_check in ['IpAddress','FQDN','MachineName','OperatingSystem','CoreMachineId']:
    if data_dict[item_check] == '' or data_dict[item_check] == None:
        sys.exit("Value " + item_check + " is null or empty.")

os_detail = data_dict['OperatingSystem']
os_family = ca_functions.which_os(os_detail)
if os_family == 'other': 
    sys.exit("Unable to determine Operating System type.")

# secret_dict = get_tss_secret(int(data_dict['SecretNumber']))
# for item_check in ['username','password']:
#     if secret_dict[item_check] == '' or secret_dict[item_check] == None:
#         sys.exit("Secret value " + item_check + " is null or empty.")

# ansible_username = secret_dict['username']
# ansible_password = secret_dict['password']

target_dir = os.getcwd() + "/" + inventory_dir
if not os.path.exists(target_dir):
    os.makedirs(target_dir)
inventory_file = target_dir + "/" + inventory_file

# if secret_dict["secretTemplateId"] == tss_ssh_secret_template_id:
    # ssh_target_dir = os.path.join(os.getcwd(), inventory_dir, ssh_dir)

    # if not os.path.exists(ssh_target_dir):
    #     os.makedirs(ssh_target_dir, mode=0o700)

    # ssh_private_key_path = os.path.join(ssh_target_dir, ssh_private_key_file)
    # ssh_public_key_path = os.path.join(ssh_target_dir, ssh_public_key_file)

    # # Replace these with the appropriate values
    # KEY_NAME = "id_rsa"

    # # Get SSH key from TSS
    # cmd_private_key = f"curl -H 'Authorization: Bearer {token}' -o {ssh_private_key_path} https://creds.pan.net.nz/SecretServer/api/v1/secrets/{int(data_dict['SecretNumber'])}/fields/private-key"
    # result = subprocess.run(cmd_private_key, shell=True, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # cmd_public_key = f"curl -H 'Authorization: Bearer {token}' -o {ssh_public_key_path} https://creds.pan.net.nz/SecretServer/api/v1/secrets/{int(data_dict['SecretNumber'])}/fields/public-key"
    # result = subprocess.run(cmd_public_key, shell=True, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # # Convert line endings to Unix format
    # key_files = [f"{ssh_target_dir}/{KEY_NAME}", f"{ssh_target_dir}/{KEY_NAME}.pub"]
    # result = subprocess.run(["dos2unix"] + key_files, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # # Restrict permissions to owner only
    # for key_path in [ssh_private_key_path, ssh_public_key_path]:
    #     os.chmod(key_path, 0o600)

    # # Set environment variables for key paths
    # private_key_path = os.path.realpath(ssh_private_key_path)
    # public_key_path = os.path.realpath(ssh_public_key_path)

if os_family == 'windows':
    connection = 'winrm'
    port = winrm_port
    become_method = 'runas'
    # become_user = secret_dict['username']
if os_family == 'linux':
    connection = 'ssh'
    port = ssh_port
    become_method = 'sudo'
    become_user = 'root'

name = data_dict['MachineName'].split('.')[0]
ipaddress = str(data_dict['IpAddress'])
ipaddress = re.sub(" ","",ipaddress)
ipaddress = ipaddress.split(',')[0]

target_dir = target_dir + "/group_vars/all"
if not os.path.exists(target_dir): 
    os.makedirs(target_dir)
# vault_file = target_dir + "/" + vault_file

# vault = Vault(vault_password)
# vault_content = {
#     "ansible_password":ansible_password,
#     "ansible_become_password":ansible_password
# }
# vault.dump(vault_content, open(vault_file, 'w'))

inventory = {
    'env_group': ccl_environment,
    'target': data_dict['FQDN'],
    'vars': {
        'ansible_host': data_dict['FQDN'],
        # 'ansible_user': ansible_username,
        'ansible_user': 'test_user', # Change this back to a variable
        # "ansible_password": 'test_password', # Change this back to a variable
        'ansible_become_user': 'become_user', # Change this back to a variable
        # "ansible_become_password": 'ansible_password', # Change this back to a variable
        'ansible_become_method': become_method,
        'ansible_connection': connection,
        'ansible_port': port,
        'remote_addr': ipaddress,
        'ccl_os_family': os_family,
        'ccl_os': os_detail,
        'ccl_machine_id': data_dict['CoreMachineId'],
        'ccl_machine_externalid': data_dict['ExternalMachineId'],
        'ccl_machine_fqdn': data_dict['FQDN'],
        'job_queue_id': data_dict['JobQueueId'],
        'job_queue_task_id': data_dict['JobQueueTaskId'],
        'ccl_vcenter_fqdn': data_dict['vCenterFQDN'],
        'ccl_service': data_dict['Service'],
        'ccl_environment': ccl_environment,
        'ccl_location': data_dict['Location'],
        'customer_ref': customer_ref,
        'customer_name': data_dict['CustomerName'],
        'customer_name_clean': ca_functions.clean_string(data_dict['CustomerName'])
    }
}

if data_dict['Payload'] != None and data_dict['Payload'] != {} and data_dict['Payload'] != '':
    for key, value in data_dict['Payload'].items():
        if value == None:
            value = ''
        clean_key = ca_functions.clean_string(key)
        inventory['vars'][clean_key] = value

# if os_family == 'linux' and secret_dict["secretTemplateId"] == tss_ssh_secret_template_id :
#     inventory["all"]["children"][ccl_environment]["hosts"][name]['ansible_ssh_private_key_file'] = private_key_path

if os_family == 'windows':
    inventory['vars']['ansible_winrm_scheme'] = winrm_scheme
    inventory['vars']['ansible_winrm_transport'] = winrm_transport
    inventory['vars']['ansible_winrm_message_encryption'] = "always"

print(json.dumps(inventory))