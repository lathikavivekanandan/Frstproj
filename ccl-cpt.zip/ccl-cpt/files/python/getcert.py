from certsrv import Certsrv
import argparse
import os
from pathlib import Path

# https://certsrv.readthedocs.io/en/latest/certsrv.html

# Expected usage:
# python getcert.py <csr file> <ca server address> <template to use> <path pem file will be saved to> <path chain file will be saved to>

# Argparse setup

parser = argparse.ArgumentParser()
parser.add_argument("-s", "--server", dest="server", required=True, type=str, help="Certificate authority server address.", nargs=1, metavar="SERVER")
parser.add_argument("-t", "--template", dest="template", required=True, type=str, help="Name of the certificate template to request.", nargs=1, metavar="TEMPLATE")
parser.add_argument("-r", "--request", dest="csr", required=True, type=str, help="Certificate signing request file.", nargs=1, metavar="CSR")
parser.add_argument("-o", "--out-file", dest="outfile", required=True, type=str, help="File path where signed certificate will be written out.", nargs=1, metavar="OUT FILE")
parser.add_argument("-u", "--username", dest="username", required=True, type=str, help="Username with permission to request certificate signing.", nargs=1, metavar="USERNAME")
parser.add_argument("-p", "--password", dest="password", required=False, type=str, default=None, help="User password, will use ENV var CERTSRV_PASSWORD if not specified.", nargs=1, metavar="PASSWORD")
parser.add_argument("-c", "--out-chain", dest="outchain", required=False, type=str, default=None, help="Optional file path where CA chain file will be written out.", nargs=1, metavar="OUT CHAIN")
args = parser.parse_args()

# Set fixed variables

cert_encoding = "b64"
auth_method = "ntlm"

# Parse argument values

ca_host = str(args.server[0])
cert_template = str(args.template[0])
csr_file = os.path.abspath(args.csr[0])
out_pem = os.path.abspath(args.outfile[0])
if args.outchain != None:
    out_chain = os.path.abspath(args.outchain[0])
else:
    out_chain = None
username = str(args.username[0])
if args.password != None:
    password = str(args.password[0])
else:
    password = None

print("=====")
print(csr_file)
print(out_pem)
print(out_chain)
print(ca_host)
print(cert_template)
print("=====")

# Get password from environment variable if not specified in args

if password == None and "CERTSRV_PASSWORD" in os.environ:
    password = os.environ["CERTSRV_PASSWORD"]
elif password == None and "CERTSRV_PASSWORD" not in os.environ:
    print("Password not specified in arguments or in env variable CERTSRV_PASSWORD, exiting.")
    exit(1)

# Create the certsrv object

ca_server = Certsrv(server=ca_host, username=username, password=password, auth_method=auth_method)

# Get the CSR file data imported to the pem_req var, correctly serialized

with open(csr_file, 'r') as file:
    pem_request = file.read()

# Get the certificate issued by the CA, value returned to a variable
# Write the pem_cert and pem_chain vars out to files (out_pem and out_chain)

pem_cert = ca_server.get_cert(csr=pem_request, template=cert_template, encoding=cert_encoding)
with open(out_pem, 'w') as f:
    print(pem_cert.decode(), file=f)

# Get the CA chain value and write out to file, if requested

if out_chain != None:
    pem_chain = ca_server.get_ca_cert(cert_encoding)
    with open(out_chain, 'w') as f:
        print(pem_chain.decode(), file=f)