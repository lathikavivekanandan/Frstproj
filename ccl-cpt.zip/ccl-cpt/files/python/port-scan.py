#--------------------------
# Define modules to import.
#--------------------------

import sys
import re
from ca_functions import get_tss_secret, load_job_data, which_os
import socket
from socket import AF_INET, SOCK_STREAM
import os
import pymssql
import ssl
import OpenSSL.crypto
import json
import ast
from datetime import datetime

#-------------------------
# Define static variables.
#-------------------------

sql_secret_id = 6088222
sql_update_port_proc = "dbo.CoreMachine_InsertOrUpdate"
sql_update_cert_proc = "dbo.Certificate_InsertOrUpdate"
sql_update_log_proc = "dbo.AnsibleLog_InsertOrUpdate"
sql_update_fact_proc = "dbo.AnsibleFact_InsertOrUpdate"
ports_windows = [
    {"number": 5985, "tls": False},
    {"number": 5986, "tls": True}
]
ports_unix = [
    {"number": 22, "tls": False}
]

#------------------------------
# Define environment variables.
#------------------------------



#------------------
# Define functions.
#------------------

def sql_update_cert(update_item: dict):
    
    cert_update_dict = {
        "Certificates": [{
            "Thumbprint": update_item['CertThumbprint'],
            "CN": update_item['CertCN'],
            "Issuer": update_item['CertIssuer'],
            "NotBefore": update_item['CertNotBefore'],
            "NotAfter": update_item['CertNotAfter'],
            "Key": {
                "Type": update_item['CertKeyType'],
                "Length": update_item['CertKeyLength'],
                "Usage": update_item['CertKeyUsage'],
                "ExtendedUsage": update_item['CertExtendedKeyUsage']
            },
            "San": update_item['CertSan']
        }]
    }
    cert_update_json = json.dumps(cert_update_dict)
    print(cert_update_json)
    cur.callproc(sql_update_cert_proc, (cert_update_json,))

def sql_update_port(update_item: dict):

    port_update_dict = {
        "CoreMachines": [{
            "CoreMachineID": int(update_item['id']),
            "FQDN": update_item['fqdn'], 
            "Ports": [{
                "IpAddress": str(update_item['address']), 
                "Port": int(update_item['port']), 
                "Status": str(update_item['PortStatus']), 
                "IsOpen": int(update_item['PortIsOpen']), 
                "IsTLS": int(update_item['tls'])
            }]
        }]
    }

    if 'CertThumbprint' in update_item.keys():
        port_update_dict['CoreMachines'][0]["Bindings"] = [{
            "CertificateThumbprint": update_item['CertThumbprint']
        }]

    port_update_json = json.dumps(port_update_dict)
    print(port_update_json)
    cur.callproc(sql_update_port_proc, (port_update_json,))

def get_cert_none():
        cert_none_dict = {}
        cert_none_dict['CertCN'] = "None"
        cert_none_dict['CertThumbprint'] = "0000000000000000000000000000000000000000"
        cert_none_dict['CertIssuer'] = "None"
        cert_none_dict['CertNotBefore'] = datetime(1970,1,1,0,0,0).strftime("%Y-%m-%d %H:%M:%S")
        cert_none_dict['CertNotAfter'] = datetime(2100,12,31,11,59,59).strftime("%Y-%m-%d %H:%M:%S")
        cert_none_dict['CertKeyType'] = "None"
        cert_none_dict['CertKeyLength'] = 0
        cert_none_dict['CertKeyUsage'] = ["None"]
        cert_none_dict['CertExtendedKeyUsage'] = ["None"]
        cert_none_dict['CertSan'] = ["None"]
        cert_none_dict['LastChecked'] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        return cert_none_dict

def get_cert_key_type(cert: OpenSSL.crypto.X509):
    if cert.get_pubkey().type() == OpenSSL.crypto.TYPE_RSA:
        key_type = 'RSA'
    elif cert.get_pubkey().type() == OpenSSL.crypto.TYPE_DSA:
        key_type = 'ECC'
    else:
        key_type = cert.get_pubkey().type()
    return key_type

def get_cert_altnames(cert: OpenSSL.crypto.X509):
    for index in range(cert.get_extension_count()):
        extension = cert.get_extension(index)
        if extension.get_short_name() == b'subjectAltName':
            dns_names = []
            for alt_name in str(extension).split(', '):
                if alt_name.startswith('DNS:'):
                    dns_names.append(alt_name[4:])
    return dns_names

def get_cert_key_usage(cert: OpenSSL.crypto.X509):
    for index in range(cert.get_extension_count()):
        extension = cert.get_extension(index)
        if extension.get_short_name() == b'keyUsage':
            key_usage = str(extension).split(', ')
    return key_usage

def get_cert_extended_key_usage(cert: OpenSSL.crypto.X509):
    for index in range(cert.get_extension_count()):
        extension = cert.get_extension(index)
        if extension.get_short_name() == b'extendedKeyUsage':
            extended_key_usage = str(extension).split(', ')
    return extended_key_usage

def get_cert(cert: OpenSSL.crypto.X509):
    not_before = datetime.strptime(cert.get_notBefore().decode('utf-8'), '%Y%m%d%H%M%SZ')
    not_after = datetime.strptime(cert.get_notAfter().decode('utf-8'), '%Y%m%d%H%M%SZ')
    cert_dict = {}
    cert_dict['CertCN'] = cert.get_subject().CN
    cert_dict['CertThumbprint'] = cert.digest('sha1').decode('utf-8').lower().replace(':','')
    cert_dict['CertIssuer'] = cert.get_issuer().CN
    cert_dict['CertNotBefore'] = not_before.strftime("%Y-%m-%d %H:%M:%S")
    cert_dict['CertNotAfter'] = not_after.strftime("%Y-%m-%d %H:%M:%S")
    cert_dict['CertKeyType'] = get_cert_key_type(cert)
    cert_dict['CertKeyLength'] = cert.get_pubkey().bits()
    cert_dict['CertKeyUsage'] = get_cert_key_usage(cert)
    cert_dict['CertExtendedKeyUsage'] = get_cert_extended_key_usage(cert)
    cert_dict['CertSan'] = get_cert_altnames(cert)
    cert_dict['LastChecked'] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    return cert_dict

def port_scan(item: dict):
    address = item['address']
    port = item['port']
    try:
        with socket.socket(AF_INET, SOCK_STREAM) as sock:
            sock.settimeout(1)    
            sock.connect((address, port)) # basic tcp connection, port is open if it connects
            item['PortIsOpen'] = True
            item['PortStatus'] = "Open"
    except socket.gaierror as e:
        item['PortIsOpen'] = False
        item['PortStatus'] = e.strerror
    except socket.error as e:
        item['PortIsOpen'] = False
        item['PortStatus'] = e.strerror
    except socket.socket.timeout:
        item['PortIsOpen'] = False
        item['PortStatus'] = 'Timeout'
    except Exception:
        item['PortIsOpen'] = False
        item['PortStatus'] = "Unknown"
    if item['tls'] and item['PortIsOpen']: # if the port is marked as tls (ie 5986) and isn't blocked by firewall, also gather cert info
        try:                    
            pem = ssl.get_server_certificate((address,port),ca_certs=None)
            x509 = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM,pem)
            cert = get_cert(x509) # when connection is successful certificate info is added
        except ssl.SSLError as e:
            item['PortIsOpen'] = False
            item['PortStatus'] = e.strerror
            cert = {}
        except Exception:
            item['PortIsOpen'] = False
            item['PortStatus'] = "Unknown TLS error"
            cert = {}
        item = item | cert
    if item['PortStatus'] == None:
        item['PortStatus'] = ''    
    return item

def sql_update_logs(update_item: dict):
    log_update_dict = {
        "JobQueueId":  update_item['queueId'],
        "JobQueueTaskId": update_item['taskId'],
        "MachineId": update_item['id'],
        "Status": overall_status,
        "ErrorCode": error_code,
        "ErrorMessage": error_message
    }
    log_update_json = json.dumps(log_update_dict)
    print(log_update_json)
    cur.callproc(sql_update_log_proc, (log_update_json,))

def sql_update_facts(update_item: dict):
    date_time = datetime.now()
    sub_fact_update_dict = {
        "machine_fqdn": update_item['machine_fqdn'],
        "jobqueue_id":  update_item['queueId'],
        "jobtask_id": update_item['taskId'],
        "customer_name": update_item['customer'],
        "operating_system": update_item['os'],
        "service": update_item['service'],
        "location": update_item['location'],
        "vCenter_FQDN": update_item['vCenter_fqdn'],
        "certificate_DB_update": cert_status,
        "port_DB_update": port_status,
        "overall_status": overall_status,
        "error_code": error_code,
        "error_message": error_message
    }
    fact_update_dict ={
        "AnsibleFacts": [
            {
                "CoreMachineID": int(update_item['id']),
                "FQDN": update_item['machine_fqdn'],
                "Workflow": "Port-Scan",
                "Facts": sub_fact_update_dict,
                "WhenCreated": date_time.strftime("%Y-%m-%d %H:%M:%S")
            }
        ]
    }
    fact_update_json = json.dumps(fact_update_dict)
    print(fact_update_json)
    cur.callproc(sql_update_fact_proc, (fact_update_json,))

#-------------
# Script body.
#-------------

data_string = os.getenv('JOB_DATA', default=None)
if data_string == None or data_string == '':
    sys.exit("JOB_DATA environment variable not set.")
print(data_string)
data_dict = load_job_data(str(data_string))
print(data_dict)
data_address = ast.literal_eval(data_dict['IpAddresses'])                                     
db = get_tss_secret(int(sql_secret_id))

context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
context.options &= ~ssl.OP_NO_SSLv3
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE

os_type = which_os(str(data_dict['OperatingSystem']))

match os_type:
    case 'windows':
        ports = ports_windows
    case 'linux':
        ports = ports_unix
    case 'other':
        sys.exit("Operating System type not supported.")
    case _:
        sys.exit('Error determining OS type.')

    # Convert job data into a flat list

scan_list = []
for address in data_address:
    address = re.sub(" ","",address)
    for port_dict in ports:
        scan_dict = { "id": data_dict['CoreMachineId'], "fqdn": data_dict['FQDN'], "address": address, "port": port_dict['number'], "tls": port_dict['tls'], "queueId": data_dict['JobQueueId'], "taskId": data_dict['JobQueueTaskId'], "machine_fqdn": data_dict['MachineName'], "customer": data_dict['CustomerName'], "os": data_dict['OperatingSystem'], "service": data_dict['Service'], "location": data_dict['Location'], "vCenter_fqdn": data_dict['vCenterFQDN'] }
        scan_list.append(scan_dict)

    # Run port scan for each row in flat list

for index, scan_dict in enumerate(scan_list):
    scan_list[index] = port_scan(scan_dict) 

    # Update Core Automation tables with flat list data

cert_failures = []
port_failures = []
overall_failure = []
overall_status = "failed"
cert_status  = False
port_status = False
error_message = "Null"
error_code = "0"

conn = pymssql.connect(
    server=db["server"], 
    port=db["port"], 
    database=db["database"],
    user=db["username"], 
    password=db["password"],
    autocommit=True
    )
cur = conn.cursor()

cert_count = 0

for scan_dict in scan_list:
    if 'CertThumbprint' in scan_dict.keys():
        try:
            # Increment cert-count
            cert_count += 1
            sql_update_cert(scan_dict)
        except Exception as e:
            cert_failures.append(scan_dict['fqdn'] + " " + scan_dict['CertCN'] + " : " + str(e))
    try:
        sql_update_port(scan_dict)
    except Exception as e:
        port_failures.append(scan_dict['fqdn'] + " Port " + str(scan_dict['port']) + " : " + str(e))

exit_code = 0

if len(cert_failures) > 0 and cert_count > 0:
    print('===== Certificate update failures =====')
    print(*cert_failures, sep="\n")
    exit_code = 1
elif len(cert_failures) == 0 and cert_count > 0:
    print('===== All certificate updates succeeded =====')
    cert_status = True
elif cert_count == 0:
    print('===== No certificates to update =====')
    cert_status = True
if len(port_failures) > 0:
    print('===== Port update failures =====')
    print(*port_failures, sep="\n")
    exit_code = 1
else:
    print('===== All port updates succeeded =====')
    port_status = True

if(cert_status and port_status):
    overall_status = "completed"
cert_failures.extend(port_failures)
error_message = ", ".join(cert_failures) if cert_failures else "Null"
if len(scan_list) > 0:
    log_dict = scan_list[0]
    sql_update_facts(log_dict)
    sql_update_logs(log_dict)
conn.close()
sys.exit(exit_code)